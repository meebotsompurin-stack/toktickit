import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=15734ece";
import "/node_modules/bootstrap/dist/css/bootstrap.min.css";
import { MyTickets } from "/src/components/MyTickets.tsx";
import { DevRequesterSelector } from "/src/components/DevRequesterSelector.tsx";
import { CreateTicket } from "/src/components/CreateTicket.tsx";
import { TicketDetail } from "/src/components/TicketDetail.tsx";
var _jsxFileName = "C:/Users/meebo/toktickit/client/src/App.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=15734ece";
var _s = $RefreshSig$();
function App() {
	_s();
	const [healthLoading, setHealthLoading] = useState(false);
	const [status, setStatus] = useState(null);
	const getInitialRequester = () => {
		const saved = localStorage.getItem("toktickit_requester");
		if (saved) {
			try {
				return JSON.parse(saved);
			} catch (e) {
				return null;
			}
		}
		return null;
	};
	const [loggedInRequester, setLoggedInRequester] = useState(getInitialRequester());
	const [view, setView] = useState("LIST");
	const [selectedTicketId, setSelectedTicketId] = useState(null);
	const handleCheckSystem = async () => {
		setHealthLoading(true);
		setStatus("Loading...");
		try {
			const response = await fetch("/api/health");
			if (response.ok) {
				setStatus("System Status: Online");
			} else {
				setStatus("System Status: Offline. Unable to connect to TokTickIT API");
			}
		} catch (err) {
			console.error("Error checking system health:", err);
			setStatus("System Status: Offline. Unable to connect to TokTickIT API");
		} finally {
			setHealthLoading(false);
		}
	};
	const handleCreateSuccess = () => {
		alert("Ticket created successfully!");
		setView("LIST");
	};
	const handleViewTicket = (ticketId) => {
		setSelectedTicketId(ticketId);
		setView("DETAIL");
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-zenBg text-gray-800 font-sans flex flex-col",
		children: [/* @__PURE__ */ _jsxDEV("header", {
			className: "bg-white shadow-sm border-b border-zenPale p-4 sticky top-0 z-10 shrink-0",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-5xl mx-auto flex justify-between items-center",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-2 cursor-pointer",
					onClick: () => setView("LIST"),
					children: [/* @__PURE__ */ _jsxDEV("svg", {
						className: "w-8 h-8 text-zenPrimary",
						fill: "currentColor",
						viewBox: "0 0 20 20",
						children: /* @__PURE__ */ _jsxDEV("path", { d: "M10 2a8 8 0 100 16 8 8 0 000-16zm1 11H9v-2h2v2zm0-4H9V5h2v4z" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 94
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("h1", {
						className: "text-2xl font-black text-zenPrimary tracking-tight",
						children: ["TokTick", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-zenSecondary",
							children: "IT"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 87
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex space-x-4 items-center",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: handleCheckSystem,
						disabled: healthLoading,
						className: "text-sm px-4 py-2 border border-zenPrimary text-zenPrimary hover:bg-zenPale rounded-full transition-colors font-medium flex items-center space-x-1",
						children: /* @__PURE__ */ _jsxDEV("span", { children: healthLoading ? "Checking..." : "Check System" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 13
					}, this), loggedInRequester && /* @__PURE__ */ _jsxDEV("button", {
						className: "text-sm text-gray-500 hover:text-red-500 font-semibold",
						onClick: () => {
							localStorage.removeItem("toktickit_requester");
							setLoggedInRequester(null);
							setView("LIST");
						},
						children: [
							"Logout (",
							loggedInRequester.name,
							")"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 64,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("main", {
			className: "p-4 max-w-5xl mx-auto w-full flex-grow",
			children: [
				status && /* @__PURE__ */ _jsxDEV("div", {
					className: `mb-6 p-3 rounded shadow-sm text-sm font-semibold border ${status.includes("Online") ? "bg-zenPale text-zenPrimary border-zenPrimary/20" : "bg-red-50 text-red-600 border-red-200"}`,
					children: status
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 98,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "bg-white p-6 rounded-lg shadow-sm border border-gray-100 mb-6 flex flex-col md:flex-row justify-between items-center gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-lg font-bold text-gray-800 mb-2",
							children: "Simulate Login (Dev Mode)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 105,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(DevRequesterSelector, { onSelect: (req) => {
							setLoggedInRequester(req);
							setView("LIST");
						} }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 106,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 11
					}, this), loggedInRequester && view === "LIST" && /* @__PURE__ */ _jsxDEV("button", {
						className: "px-4 py-2 rounded font-semibold text-white bg-zenPrimary hover:bg-zenSecondary shadow-md transition-colors shrink-0",
						onClick: () => setView("CREATE"),
						children: "+ Create New Ticket"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 103,
					columnNumber: 9
				}, this),
				!loggedInRequester ? /* @__PURE__ */ _jsxDEV("div", {
					className: "text-center p-12 bg-white rounded-lg border border-dashed border-gray-300",
					children: [/* @__PURE__ */ _jsxDEV("svg", {
						className: "w-16 h-16 text-gray-300 mx-auto mb-4",
						fill: "none",
						stroke: "currentColor",
						viewBox: "0 0 24 24",
						children: /* @__PURE__ */ _jsxDEV("path", {
							strokeLinecap: "round",
							strokeLinejoin: "round",
							strokeWidth: "2",
							d: "M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 121
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-gray-500 font-medium",
						children: "Please select a requester above to continue."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 125,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV("div", { children: [
					view === "LIST" && /* @__PURE__ */ _jsxDEV(MyTickets, { onView: handleViewTicket }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 33
					}, this),
					view === "CREATE" && /* @__PURE__ */ _jsxDEV(CreateTicket, {
						onCancel: () => setView("LIST"),
						onSuccess: handleCreateSuccess
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 132,
						columnNumber: 35
					}, this),
					view === "DETAIL" && selectedTicketId && /* @__PURE__ */ _jsxDEV(TicketDetail, {
						ticketId: selectedTicketId,
						onBack: () => setView("LIST")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 134,
						columnNumber: 15
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 130,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 95,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 63,
		columnNumber: 5
	}, this);
}
_s(App, "HzxXgkwYIAXPCd5WJSdWT7sJa4c=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/meebo/toktickit/client/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/meebo/toktickit/client/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/meebo/toktickit/client/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsT0FBTztBQUNQLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsNEJBQTRCO0FBQ3JDLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsb0JBQW9COzs7O0FBTzdCLFNBQVMsTUFBTTs7Q0FDYixNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBUyxLQUFLO0NBQ3hELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBd0IsSUFBSTtDQUV4RCxNQUFNLDRCQUE4QztFQUNsRCxNQUFNLFFBQVEsYUFBYSxRQUFRLHFCQUFxQjtFQUN4RCxJQUFJLE9BQU87R0FDVCxJQUFJO0lBQ0YsT0FBTyxLQUFLLE1BQU0sS0FBSztHQUN6QixTQUFTLEdBQUc7SUFDVixPQUFPO0dBQ1Q7RUFDRjtFQUNBLE9BQU87Q0FDVDtDQUVBLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQTJCLG9CQUFvQixDQUFDO0NBRWxHLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBdUMsTUFBTTtDQUNyRSxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUF3QixJQUFJO0NBRTVFLE1BQU0sb0JBQW9CLFlBQVk7RUFDcEMsaUJBQWlCLElBQUk7RUFDckIsVUFBVSxZQUFZO0VBQ3RCLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxNQUFNLGFBQWE7R0FDMUMsSUFBSSxTQUFTLElBQUk7SUFDZixVQUFVLHVCQUF1QjtHQUNuQyxPQUFPO0lBQ0wsVUFBVSw0REFBNEQ7R0FDeEU7RUFDRixTQUFTLEtBQUs7R0FDWixRQUFRLE1BQU0saUNBQWlDLEdBQUc7R0FDbEQsVUFBVSw0REFBNEQ7RUFDeEUsVUFBVTtHQUNSLGlCQUFpQixLQUFLO0VBQ3hCO0NBQ0Y7Q0FFQSxNQUFNLDRCQUE0QjtFQUNoQyxNQUFNLDhCQUE4QjtFQUNwQyxRQUFRLE1BQU07Q0FDaEI7Q0FFQSxNQUFNLG9CQUFvQixhQUFxQjtFQUM3QyxvQkFBb0IsUUFBUTtFQUM1QixRQUFRLFFBQVE7Q0FDbEI7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxVQUFEO0dBQVEsV0FBVTthQUNoQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBNkMsZUFBZSxRQUFRLE1BQU07ZUFBekYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUEwQixNQUFLO01BQWUsU0FBUTtnQkFBWSx3QkFBQyxRQUFELEVBQU0sR0FBRSwrREFBcUU7Ozs7O0tBQU07Ozs7ZUFDcEssd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQsQ0FBbUUsV0FBTyx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBb0I7TUFBUTs7OztjQUFLOzs7OzthQUN4SDs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxVQUFVO01BQ1YsV0FBVTtnQkFFVix3QkFBQyxRQUFELFlBQU8sZ0JBQWdCLGdCQUFnQixlQUFxQjs7Ozs7S0FDdEQ7Ozs7ZUFDUCxxQkFDQyx3QkFBQyxVQUFEO01BQ0UsV0FBVTtNQUNWLGVBQWU7T0FDYixhQUFhLFdBQVcscUJBQXFCO09BQzdDLHFCQUFxQixJQUFJO09BQ3pCLFFBQVEsTUFBTTtNQUNoQjtnQkFORjtPQU9DO09BQ1Usa0JBQWtCO09BQUs7TUFDMUI7Ozs7O2FBRVA7Ozs7O1lBQ0Y7Ozs7OztFQUNDOzs7O1lBRVIsd0JBQUMsUUFBRDtHQUFNLFdBQVU7YUFBaEI7SUFFRyxVQUNDLHdCQUFDLE9BQUQ7S0FBSyxXQUFXLDJEQUEyRCxPQUFPLFNBQVMsUUFBUSxJQUFJLG9EQUFvRDtlQUN4SjtJQUNFOzs7OztJQUdQLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUF1QztNQUE2Qjs7OztnQkFDbEYsd0JBQUMsc0JBQUQsRUFDRSxXQUFXLFFBQVE7T0FDakIscUJBQXFCLEdBQUc7T0FDeEIsUUFBUSxNQUFNO01BQ2hCLEVBQ0Q7Ozs7Y0FDRTs7Ozs7ZUFFSixxQkFBcUIsU0FBUyxVQUM3Qix3QkFBQyxVQUFEO01BQ0UsV0FBVTtNQUNWLGVBQWUsUUFBUSxRQUFRO2dCQUNoQztLQUVPOzs7O2FBRVA7Ozs7OztJQUVKLENBQUMsb0JBQ0Esd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQXVDLE1BQUs7TUFBTyxRQUFPO01BQWUsU0FBUTtnQkFBWSx3QkFBQyxRQUFEO09BQU0sZUFBYztPQUFRLGdCQUFlO09BQVEsYUFBWTtPQUFJLEdBQUU7TUFBNkc7Ozs7O0tBQU07Ozs7ZUFDcFMsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQTRCO0tBQStDOzs7O2FBQ3JGOzs7OztlQUVMLHdCQUFDLE9BQUQ7S0FDRyxTQUFTLFVBQVUsd0JBQUMsV0FBRCxFQUFXLFFBQVEsaUJBQW1COzs7OztLQUN6RCxTQUFTLFlBQVksd0JBQUMsY0FBRDtNQUFjLGdCQUFnQixRQUFRLE1BQU07TUFBRyxXQUFXO0tBQXNCOzs7OztLQUNyRyxTQUFTLFlBQVksb0JBQ3BCLHdCQUFDLGNBQUQ7TUFBYyxVQUFVO01BQWtCLGNBQWMsUUFBUSxNQUFNO0tBQUk7Ozs7O0lBRXpFOzs7OztHQUdIOzs7OztVQUNIOzs7Ozs7QUFFVDs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0ICdib290c3RyYXAvZGlzdC9jc3MvYm9vdHN0cmFwLm1pbi5jc3MnO1xuaW1wb3J0IHsgTXlUaWNrZXRzIH0gZnJvbSAnLi9jb21wb25lbnRzL015VGlja2V0cyc7XG5pbXBvcnQgeyBEZXZSZXF1ZXN0ZXJTZWxlY3RvciB9IGZyb20gJy4vY29tcG9uZW50cy9EZXZSZXF1ZXN0ZXJTZWxlY3Rvcic7XG5pbXBvcnQgeyBDcmVhdGVUaWNrZXQgfSBmcm9tICcuL2NvbXBvbmVudHMvQ3JlYXRlVGlja2V0JztcbmltcG9ydCB7IFRpY2tldERldGFpbCB9IGZyb20gJy4vY29tcG9uZW50cy9UaWNrZXREZXRhaWwnO1xuXG5pbnRlcmZhY2UgUmVxdWVzdGVyIHtcbiAgaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xufVxuXG5mdW5jdGlvbiBBcHAoKSB7XG4gIGNvbnN0IFtoZWFsdGhMb2FkaW5nLCBzZXRIZWFsdGhMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3N0YXR1cywgc2V0U3RhdHVzXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBcbiAgY29uc3QgZ2V0SW5pdGlhbFJlcXVlc3RlciA9ICgpOiBSZXF1ZXN0ZXIgfCBudWxsID0+IHtcbiAgICBjb25zdCBzYXZlZCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCd0b2t0aWNraXRfcmVxdWVzdGVyJyk7XG4gICAgaWYgKHNhdmVkKSB7XG4gICAgICB0cnkge1xuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShzYXZlZCk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfTtcbiAgXG4gIGNvbnN0IFtsb2dnZWRJblJlcXVlc3Rlciwgc2V0TG9nZ2VkSW5SZXF1ZXN0ZXJdID0gdXNlU3RhdGU8UmVxdWVzdGVyIHwgbnVsbD4oZ2V0SW5pdGlhbFJlcXVlc3RlcigpKTtcbiAgXG4gIGNvbnN0IFt2aWV3LCBzZXRWaWV3XSA9IHVzZVN0YXRlPCdMSVNUJyB8ICdDUkVBVEUnIHwgJ0RFVEFJTCc+KCdMSVNUJyk7XG4gIGNvbnN0IFtzZWxlY3RlZFRpY2tldElkLCBzZXRTZWxlY3RlZFRpY2tldElkXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IGhhbmRsZUNoZWNrU3lzdGVtID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldEhlYWx0aExvYWRpbmcodHJ1ZSk7XG4gICAgc2V0U3RhdHVzKCdMb2FkaW5nLi4uJyk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goJy9hcGkvaGVhbHRoJyk7XG4gICAgICBpZiAocmVzcG9uc2Uub2spIHtcbiAgICAgICAgc2V0U3RhdHVzKCdTeXN0ZW0gU3RhdHVzOiBPbmxpbmUnKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNldFN0YXR1cygnU3lzdGVtIFN0YXR1czogT2ZmbGluZS4gVW5hYmxlIHRvIGNvbm5lY3QgdG8gVG9rVGlja0lUIEFQSScpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgY2hlY2tpbmcgc3lzdGVtIGhlYWx0aDonLCBlcnIpO1xuICAgICAgc2V0U3RhdHVzKCdTeXN0ZW0gU3RhdHVzOiBPZmZsaW5lLiBVbmFibGUgdG8gY29ubmVjdCB0byBUb2tUaWNrSVQgQVBJJyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEhlYWx0aExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVDcmVhdGVTdWNjZXNzID0gKCkgPT4ge1xuICAgIGFsZXJ0KCdUaWNrZXQgY3JlYXRlZCBzdWNjZXNzZnVsbHkhJyk7XG4gICAgc2V0VmlldygnTElTVCcpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVZpZXdUaWNrZXQgPSAodGlja2V0SWQ6IHN0cmluZykgPT4ge1xuICAgIHNldFNlbGVjdGVkVGlja2V0SWQodGlja2V0SWQpO1xuICAgIHNldFZpZXcoJ0RFVEFJTCcpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctemVuQmcgdGV4dC1ncmF5LTgwMCBmb250LXNhbnMgZmxleCBmbGV4LWNvbFwiPlxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJiZy13aGl0ZSBzaGFkb3ctc20gYm9yZGVyLWIgYm9yZGVyLXplblBhbGUgcC00IHN0aWNreSB0b3AtMCB6LTEwIHNocmluay0wXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctNXhsIG14LWF1dG8gZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgY3Vyc29yLXBvaW50ZXJcIiBvbkNsaWNrPXsoKSA9PiBzZXRWaWV3KCdMSVNUJyl9PlxuICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTggaC04IHRleHQtemVuUHJpbWFyeVwiIGZpbGw9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDIwIDIwXCI+PHBhdGggZD1cIk0xMCAyYTggOCAwIDEwMCAxNiA4IDggMCAwMDAtMTZ6bTEgMTFIOXYtMmgydjJ6bTAtNEg5VjVoMnY0elwiPjwvcGF0aD48L3N2Zz5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtemVuUHJpbWFyeSB0cmFja2luZy10aWdodFwiPlRva1RpY2s8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXplblNlY29uZGFyeVwiPklUPC9zcGFuPjwvaDE+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHNwYWNlLXgtNCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNoZWNrU3lzdGVtfSBcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2hlYWx0aExvYWRpbmd9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc20gcHgtNCBweS0yIGJvcmRlciBib3JkZXItemVuUHJpbWFyeSB0ZXh0LXplblByaW1hcnkgaG92ZXI6YmctemVuUGFsZSByb3VuZGVkLWZ1bGwgdHJhbnNpdGlvbi1jb2xvcnMgZm9udC1tZWRpdW0gZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPHNwYW4+e2hlYWx0aExvYWRpbmcgPyAnQ2hlY2tpbmcuLi4nIDogJ0NoZWNrIFN5c3RlbSd9PC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICB7bG9nZ2VkSW5SZXF1ZXN0ZXIgJiYgKFxuICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBob3Zlcjp0ZXh0LXJlZC01MDAgZm9udC1zZW1pYm9sZFwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ3Rva3RpY2tpdF9yZXF1ZXN0ZXInKTtcbiAgICAgICAgICAgICAgICAgIHNldExvZ2dlZEluUmVxdWVzdGVyKG51bGwpO1xuICAgICAgICAgICAgICAgICAgc2V0VmlldygnTElTVCcpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBMb2dvdXQgKHtsb2dnZWRJblJlcXVlc3Rlci5uYW1lfSlcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvaGVhZGVyPlxuICAgICAgXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJwLTQgbWF4LXctNXhsIG14LWF1dG8gdy1mdWxsIGZsZXgtZ3Jvd1wiPlxuICAgICAgICBcbiAgICAgICAge3N0YXR1cyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BtYi02IHAtMyByb3VuZGVkIHNoYWRvdy1zbSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgYm9yZGVyICR7c3RhdHVzLmluY2x1ZGVzKCdPbmxpbmUnKSA/ICdiZy16ZW5QYWxlIHRleHQtemVuUHJpbWFyeSBib3JkZXItemVuUHJpbWFyeS8yMCcgOiAnYmctcmVkLTUwIHRleHQtcmVkLTYwMCBib3JkZXItcmVkLTIwMCd9YH0+XG4gICAgICAgICAgICB7c3RhdHVzfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcC02IHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0xMDAgbWItNiBmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgZ2FwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgbWItMlwiPlNpbXVsYXRlIExvZ2luIChEZXYgTW9kZSk8L2gyPlxuICAgICAgICAgICAgPERldlJlcXVlc3RlclNlbGVjdG9yIFxuICAgICAgICAgICAgICBvblNlbGVjdD17KHJlcSkgPT4ge1xuICAgICAgICAgICAgICAgIHNldExvZ2dlZEluUmVxdWVzdGVyKHJlcSk7XG4gICAgICAgICAgICAgICAgc2V0VmlldygnTElTVCcpO1xuICAgICAgICAgICAgICB9fSBcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgXG4gICAgICAgICAge2xvZ2dlZEluUmVxdWVzdGVyICYmIHZpZXcgPT09ICdMSVNUJyAmJiAoXG4gICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgcm91bmRlZCBmb250LXNlbWlib2xkIHRleHQtd2hpdGUgYmctemVuUHJpbWFyeSBob3ZlcjpiZy16ZW5TZWNvbmRhcnkgc2hhZG93LW1kIHRyYW5zaXRpb24tY29sb3JzIHNocmluay0wXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VmlldygnQ1JFQVRFJyl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgICsgQ3JlYXRlIE5ldyBUaWNrZXRcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHshbG9nZ2VkSW5SZXF1ZXN0ZXIgPyAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBwLTEyIGJnLXdoaXRlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1kYXNoZWQgYm9yZGVyLWdyYXktMzAwXCI+XG4gICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctMTYgaC0xNiB0ZXh0LWdyYXktMzAwIG14LWF1dG8gbWItNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPjxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTEyIDE1djJtLTYgNGgxMmEyIDIgMCAwMDItMnYtNmEyIDIgMCAwMC0yLTJINmEyIDIgMCAwMC0yIDJ2NmEyIDIgMCAwMDIgMnptMTAtMTBWN2E0IDQgMCAwMC04IDB2NGg4elwiPjwvcGF0aD48L3N2Zz5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgZm9udC1tZWRpdW1cIj5QbGVhc2Ugc2VsZWN0IGEgcmVxdWVzdGVyIGFib3ZlIHRvIGNvbnRpbnVlLjwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAge3ZpZXcgPT09ICdMSVNUJyAmJiA8TXlUaWNrZXRzIG9uVmlldz17aGFuZGxlVmlld1RpY2tldH0gLz59XG4gICAgICAgICAgICB7dmlldyA9PT0gJ0NSRUFURScgJiYgPENyZWF0ZVRpY2tldCBvbkNhbmNlbD17KCkgPT4gc2V0VmlldygnTElTVCcpfSBvblN1Y2Nlc3M9e2hhbmRsZUNyZWF0ZVN1Y2Nlc3N9IC8+fVxuICAgICAgICAgICAge3ZpZXcgPT09ICdERVRBSUwnICYmIHNlbGVjdGVkVGlja2V0SWQgJiYgKFxuICAgICAgICAgICAgICA8VGlja2V0RGV0YWlsIHRpY2tldElkPXtzZWxlY3RlZFRpY2tldElkfSBvbkJhY2s9eygpID0+IHNldFZpZXcoJ0xJU1QnKX0gLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgIDwvbWFpbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwO1xuIl19