import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MyTickets.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=15734ece";
import { getTickets, getCategories } from "/src/api.ts";
var _jsxFileName = "C:/Users/meebo/toktickit/client/src/components/MyTickets.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=15734ece";
var _s = $RefreshSig$();
export const MyTickets = ({ onView }) => {
	_s();
	const [tickets, setTickets] = useState([]);
	const [categories, setCategories] = useState([]);
	const [meta, setMeta] = useState(null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	// States for pagination and filters
	const [page, setPage] = useState(1);
	const [search, setSearch] = useState("");
	const [categoryId, setCategoryId] = useState("");
	const [priority, setPriority] = useState("");
	const [status, setStatus] = useState("");
	const [sortBy, setSortBy] = useState("createdAt");
	const [sortOrder, setSortOrder] = useState("desc");
	// Debounce search state
	const [debouncedSearch, setDebouncedSearch] = useState("");
	// Fetch categories on mount
	useEffect(() => {
		const fetchCats = async () => {
			try {
				const data = await getCategories();
				setCategories(data);
			} catch (err) {
				console.error("Failed to load categories for filter", err);
			}
		};
		fetchCats();
	}, []);
	// Handle Search Debounce
	useEffect(() => {
		const timer = setTimeout(() => {
			setDebouncedSearch(search);
			setPage(1);
		}, 500);
		return () => clearTimeout(timer);
	}, [search]);
	// Handle Filter Changes (reset page)
	const handleFilterChange = (setter, value) => {
		setter(value);
		setPage(1);
	};
	const handleClearFilters = () => {
		setSearch("");
		setCategoryId("");
		setPriority("");
		setStatus("");
		setSortBy("createdAt");
		setSortOrder("desc");
		setPage(1);
	};
	useEffect(() => {
		fetchTickets();
	}, [
		page,
		debouncedSearch,
		categoryId,
		priority,
		status,
		sortBy,
		sortOrder
	]);
	const fetchTickets = async () => {
		setLoading(true);
		setError(null);
		try {
			const response = await getTickets({
				page,
				limit: 10,
				search: debouncedSearch || undefined,
				categoryId: categoryId || undefined,
				priority: priority || undefined,
				status: status || undefined,
				sortBy,
				sortOrder
			});
			setTickets(response.data);
			setMeta(response.meta);
		} catch (err) {
			setError(err.message || "An error occurred while fetching tickets.");
		} finally {
			setLoading(false);
		}
	};
	const handleNext = () => {
		if (meta && page < meta.totalPages) setPage(page + 1);
	};
	const handlePrev = () => {
		if (page > 1) setPage(page - 1);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col md:flex-row justify-between items-start md:items-center mb-6",
				children: [/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xl font-bold text-gray-800 mb-4 md:mb-0",
					children: "My Tickets"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: handleClearFilters,
					className: "text-sm px-4 py-2 border border-gray-300 rounded text-gray-600 hover:bg-gray-50 transition-colors",
					children: "Clear Filters"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 125,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 123,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6 bg-zenPale p-4 rounded-lg border border-zenPrimary/20",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-2",
						children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-semibold text-gray-600 mb-1",
							children: "Search"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							placeholder: "Search Ticket # or Summary...",
							value: search,
							onChange: (e) => setSearch(e.target.value),
							className: "w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-zenPrimary text-sm"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 135,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-xs font-semibold text-gray-600 mb-1",
						children: "Category"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 147,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						value: categoryId,
						onChange: (e) => handleFilterChange(setCategoryId, e.target.value),
						className: "w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-zenPrimary text-sm bg-white",
						children: [/* @__PURE__ */ _jsxDEV("option", {
							value: "",
							children: "All Categories"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 153,
							columnNumber: 13
						}, this), categories.map((c) => /* @__PURE__ */ _jsxDEV("option", {
							value: c.id,
							children: c.name
						}, c.id, false, {
							fileName: _jsxFileName,
							lineNumber: 155,
							columnNumber: 15
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 146,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-xs font-semibold text-gray-600 mb-1",
						children: "Priority"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 161,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						value: priority,
						onChange: (e) => handleFilterChange(setPriority, e.target.value),
						className: "w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-zenPrimary text-sm bg-white",
						children: [
							/* @__PURE__ */ _jsxDEV("option", {
								value: "",
								children: "All Priorities"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 167,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "Low",
								children: "Low"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 168,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "Medium",
								children: "Medium"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 169,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "High",
								children: "High"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "Critical",
								children: "Critical"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 171,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 162,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 160,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-xs font-semibold text-gray-600 mb-1",
						children: "Status"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 176,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						value: status,
						onChange: (e) => handleFilterChange(setStatus, e.target.value),
						className: "w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-zenPrimary text-sm bg-white",
						children: [
							/* @__PURE__ */ _jsxDEV("option", {
								value: "",
								children: "All Statuses"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "New",
								children: "New"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "In Progress",
								children: "In Progress"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "Resolved",
								children: "Resolved"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 185,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "Closed",
								children: "Closed"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 186,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 177,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 175,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-xs font-semibold text-gray-600 mb-1",
						children: "Sort By"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						value: `${sortBy}-${sortOrder}`,
						onChange: (e) => {
							const [newSortBy, newSortOrder] = e.target.value.split("-");
							setSortBy(newSortBy);
							setSortOrder(newSortOrder);
							setPage(1);
						},
						className: "w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-1 focus:ring-zenPrimary text-sm bg-white",
						children: [
							/* @__PURE__ */ _jsxDEV("option", {
								value: "createdAt-desc",
								children: "Newest First"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 202,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "createdAt-asc",
								children: "Oldest First"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 203,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "ticketNumber-asc",
								children: "Ticket # (A-Z)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 204,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "ticketNumber-desc",
								children: "Ticket # (Z-A)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 205,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 192,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 190,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 134,
				columnNumber: 7
			}, this),
			loading && /* @__PURE__ */ _jsxDEV("p", {
				className: "text-zenPrimary font-medium py-4",
				children: "Loading tickets..."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 211,
				columnNumber: 19
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "text-red-700 font-semibold mb-4",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 213,
				columnNumber: 17
			}, this),
			!loading && !error && tickets.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
				className: "text-gray-500 bg-gray-50 p-8 rounded text-center border border-dashed border-gray-300",
				children: "No tickets found matching your criteria."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 216,
				columnNumber: 9
			}, this),
			!loading && !error && tickets.length > 0 && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "hidden md:block overflow-x-auto",
					children: /* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-left border-collapse",
						children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
							className: "bg-zenBg text-gray-700 border-b-2 border-zenPrimary",
							children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4 font-semibold",
									children: "Ticket #"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 229,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4 font-semibold",
									children: "Summary"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 230,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4 font-semibold",
									children: "Status"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 231,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4 font-semibold",
									children: "Priority"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 232,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-3 px-4 font-semibold text-center",
									children: "Action"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 233,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 228,
							columnNumber: 17
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 227,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: tickets.map((ticket) => /* @__PURE__ */ _jsxDEV("tr", {
							className: "border-b hover:bg-zenPale transition-colors",
							children: [
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-3 px-4 text-zenSecondary font-medium",
									children: onView ? /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => onView(ticket.id),
										className: "hover:underline hover:text-zenPrimary",
										children: ticket.ticketNumber
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 241,
										columnNumber: 25
									}, this) : ticket.ticketNumber
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 239,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-3 px-4 text-gray-800",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "truncate max-w-xs",
										title: ticket.summary,
										children: ticket.summary
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 249,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 248,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-3 px-4",
									children: /* @__PURE__ */ _jsxDEV("span", {
										className: "inline-block bg-zenBg text-gray-700 px-2 py-1 rounded-full text-sm border border-gray-300",
										children: ticket.status
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 254,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 253,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-3 px-4",
									children: /* @__PURE__ */ _jsxDEV("span", {
										className: `inline-block px-2 py-1 rounded-full text-sm font-semibold
                        ${ticket.requestedPriority === "High" || ticket.requestedPriority === "Critical" ? "bg-red-100 text-red-800" : ticket.requestedPriority === "Medium" ? "bg-yellow-100 text-yellow-800" : "bg-green-100 text-green-800"}`,
										children: ticket.requestedPriority
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 259,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 258,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("td", {
									className: "py-3 px-4 text-center",
									children: /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => onView && onView(ticket.id),
										className: "text-zenPrimary hover:text-white border border-zenPrimary hover:bg-zenPrimary px-3 py-1 rounded transition-colors text-sm font-medium",
										children: "View"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 267,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 266,
									columnNumber: 21
								}, this)
							]
						}, ticket.id, true, {
							fileName: _jsxFileName,
							lineNumber: 238,
							columnNumber: 19
						}, this)) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 236,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 226,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 225,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "md:hidden space-y-4",
					children: tickets.map((ticket) => /* @__PURE__ */ _jsxDEV("div", {
						className: "border rounded-lg p-4 bg-white shadow-sm hover:shadow-md transition-shadow",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between items-start mb-2",
								children: [onView ? /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => onView(ticket.id),
									className: "text-zenSecondary font-bold hover:underline",
									children: ticket.ticketNumber
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 286,
									columnNumber: 21
								}, this) : /* @__PURE__ */ _jsxDEV("span", {
									className: "text-zenSecondary font-bold",
									children: ticket.ticketNumber
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 290,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: `inline-block px-2 py-1 rounded-full text-xs font-semibold
                        ${ticket.requestedPriority === "High" || ticket.requestedPriority === "Critical" ? "bg-red-100 text-red-800" : ticket.requestedPriority === "Medium" ? "bg-yellow-100 text-yellow-800" : "bg-green-100 text-green-800"}`,
									children: ticket.requestedPriority
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 292,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 284,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-gray-800 font-medium mb-3 line-clamp-2",
								title: ticket.summary,
								children: ticket.summary
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 299,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between items-center text-sm",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "inline-block bg-zenBg text-gray-700 px-2 py-1 rounded-full border border-gray-300",
									children: ["Status: ", ticket.status]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 303,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => onView && onView(ticket.id),
									className: "text-zenPrimary font-semibold hover:underline",
									children: "View Detail"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 306,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 302,
								columnNumber: 17
							}, this)
						]
					}, ticket.id, true, {
						fileName: _jsxFileName,
						lineNumber: 283,
						columnNumber: 15
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 281,
					columnNumber: 11
				}, this),
				meta && /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col sm:flex-row justify-between items-center mt-6 pt-4 border-t border-gray-200",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-sm text-gray-600 mb-4 sm:mb-0",
						children: [
							"Showing page ",
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-zenPrimary",
								children: meta.page
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 321,
								columnNumber: 30
							}, this),
							" of ",
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-gray-800",
								children: meta.totalPages
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 321,
								columnNumber: 100
							}, this),
							" ",
							"(Total ",
							meta.total,
							" tickets)"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 320,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex space-x-2",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: handlePrev,
							disabled: page === 1,
							className: "px-4 py-2 border rounded-md text-gray-600 bg-white hover:bg-zenPale hover:text-zenPrimary disabled:opacity-50 disabled:cursor-not-allowed transition-colors focus:ring-2 focus:ring-zenPrimary focus:outline-none",
							"aria-label": "Previous page",
							children: "Previous"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 325,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: handleNext,
							disabled: page === meta.totalPages || meta.totalPages === 0,
							className: "px-4 py-2 border rounded-md text-white bg-zenPrimary hover:bg-zenSecondary disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors focus:ring-2 focus:ring-offset-1 focus:ring-zenPrimary focus:outline-none",
							"aria-label": "Next page",
							children: "Next"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 333,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 324,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 319,
					columnNumber: 13
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 223,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 122,
		columnNumber: 5
	}, this);
};
_s(MyTickets, "Wj6VttXHRbsPc8dIbFJ8Db0qvgI=");
_c = MyTickets;
var _c;
$RefreshReg$(_c, "MyTickets");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/MyTickets.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/meebo/toktickit/client/src/components/MyTickets.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/meebo/toktickit/client/src/components/MyTickets.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/meebo/toktickit/client/src/components/MyTickets.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsWUFBWSxxQkFBcUI7Ozs7QUEwQjFDLE9BQU8sTUFBTSxhQUE4QixFQUFFLGFBQWE7O0NBQ3hELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBbUIsQ0FBQyxDQUFDO0NBQ25ELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFxQixDQUFDLENBQUM7Q0FDM0QsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUEwQixJQUFJO0NBRXRELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBd0IsSUFBSTs7Q0FHdEQsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLENBQUM7Q0FDbEMsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLEVBQUU7Q0FDdkMsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsRUFBRTtDQUMzQyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsRUFBRTtDQUN2QyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsV0FBVztDQUNoRCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBeUIsTUFBTTs7Q0FHakUsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxFQUFFOztDQUd6RCxnQkFBZ0I7RUFDZCxNQUFNLFlBQVksWUFBWTtHQUM1QixJQUFJO0lBQ0YsTUFBTSxPQUFPLE1BQU0sY0FBYztJQUNqQyxjQUFjLElBQUk7R0FDcEIsU0FBUyxLQUFLO0lBQ1osUUFBUSxNQUFNLHdDQUF3QyxHQUFHO0dBQzNEO0VBQ0Y7RUFDQSxVQUFVO0NBQ1osR0FBRyxDQUFDLENBQUM7O0NBR0wsZ0JBQWdCO0VBQ2QsTUFBTSxRQUFRLGlCQUFpQjtHQUM3QixtQkFBbUIsTUFBTTtHQUN6QixRQUFRLENBQUM7RUFDWCxHQUFHLEdBQUc7RUFDTixhQUFhLGFBQWEsS0FBSztDQUNqQyxHQUFHLENBQUMsTUFBTSxDQUFDOztDQUdYLE1BQU0sc0JBQXNCLFFBQW1ELFVBQWU7RUFDNUYsT0FBTyxLQUFLO0VBQ1osUUFBUSxDQUFDO0NBQ1g7Q0FFQSxNQUFNLDJCQUEyQjtFQUMvQixVQUFVLEVBQUU7RUFDWixjQUFjLEVBQUU7RUFDaEIsWUFBWSxFQUFFO0VBQ2QsVUFBVSxFQUFFO0VBQ1osVUFBVSxXQUFXO0VBQ3JCLGFBQWEsTUFBTTtFQUNuQixRQUFRLENBQUM7Q0FDWDtDQUVBLGdCQUFnQjtFQUNkLGFBQWE7Q0FDZixHQUFHO0VBQUM7RUFBTTtFQUFpQjtFQUFZO0VBQVU7RUFBUTtFQUFRO0NBQVMsQ0FBQztDQUUzRSxNQUFNLGVBQWUsWUFBWTtFQUMvQixXQUFXLElBQUk7RUFDZixTQUFTLElBQUk7RUFDYixJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sV0FBVztJQUNoQztJQUNBLE9BQU87SUFDUCxRQUFRLG1CQUFtQjtJQUMzQixZQUFZLGNBQWM7SUFDMUIsVUFBVSxZQUFZO0lBQ3RCLFFBQVEsVUFBVTtJQUNsQjtJQUNBO0dBQ0YsQ0FBQztHQUNELFdBQVcsU0FBUyxJQUFJO0dBQ3hCLFFBQVEsU0FBUyxJQUFJO0VBQ3ZCLFNBQVMsS0FBVTtHQUNqQixTQUFTLElBQUksV0FBVywyQ0FBMkM7RUFDckUsVUFBVTtHQUNSLFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBRUEsTUFBTSxtQkFBbUI7RUFDdkIsSUFBSSxRQUFRLE9BQU8sS0FBSyxZQUFZLFFBQVEsT0FBTyxDQUFDO0NBQ3REO0NBRUEsTUFBTSxtQkFBbUI7RUFDdkIsSUFBSSxPQUFPLEdBQUcsUUFBUSxPQUFPLENBQUM7Q0FDaEM7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBK0M7SUFBYzs7OztjQUMzRSx3QkFBQyxVQUFEO0tBQ0UsU0FBUztLQUNULFdBQVU7ZUFDWDtJQUVPOzs7O1lBQ0w7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFpRDtNQUFhOzs7O2dCQUMvRSx3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMLGFBQVk7T0FDWixPQUFPO09BQ1AsV0FBVyxNQUFNLFVBQVUsRUFBRSxPQUFPLEtBQUs7T0FDekMsV0FBVTtNQUNYOzs7O2NBQ0U7Ozs7OztLQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBaUQ7S0FBZTs7OztlQUNqRix3QkFBQyxVQUFEO01BQ0UsT0FBTztNQUNQLFdBQVcsTUFBTSxtQkFBbUIsZUFBZSxFQUFFLE9BQU8sS0FBSztNQUNqRSxXQUFVO2dCQUhaLENBS0Usd0JBQUMsVUFBRDtPQUFRLE9BQU07aUJBQUc7TUFBc0I7Ozs7Z0JBQ3RDLFdBQVcsS0FBSSxNQUNkLHdCQUFDLFVBQUQ7T0FBbUIsT0FBTyxFQUFFO2lCQUFLLEVBQUU7TUFBYSxHQUFuQyxFQUFFOzs7O2FBQWlDLENBQ2pELENBQ0s7Ozs7O2FBQ0w7Ozs7O0tBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFpRDtLQUFlOzs7O2VBQ2pGLHdCQUFDLFVBQUQ7TUFDRSxPQUFPO01BQ1AsV0FBVyxNQUFNLG1CQUFtQixhQUFhLEVBQUUsT0FBTyxLQUFLO01BQy9ELFdBQVU7Z0JBSFo7T0FLRSx3QkFBQyxVQUFEO1FBQVEsT0FBTTtrQkFBRztPQUFzQjs7Ozs7T0FDdkMsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQU07T0FBVzs7Ozs7T0FDL0Isd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQVM7T0FBYzs7Ozs7T0FDckMsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQU87T0FBWTs7Ozs7T0FDakMsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQVc7T0FBZ0I7Ozs7O01BQ25DOzs7OzthQUNMOzs7OztLQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBaUQ7S0FBYTs7OztlQUMvRSx3QkFBQyxVQUFEO01BQ0UsT0FBTztNQUNQLFdBQVcsTUFBTSxtQkFBbUIsV0FBVyxFQUFFLE9BQU8sS0FBSztNQUM3RCxXQUFVO2dCQUhaO09BS0Usd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQUc7T0FBb0I7Ozs7O09BQ3JDLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFNO09BQVc7Ozs7O09BQy9CLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFjO09BQW1COzs7OztPQUMvQyx3QkFBQyxVQUFEO1FBQVEsT0FBTTtrQkFBVztPQUFnQjs7Ozs7T0FDekMsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQVM7T0FBYzs7Ozs7TUFDL0I7Ozs7O2FBQ0w7Ozs7O0tBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFpRDtLQUFjOzs7O2VBQ2hGLHdCQUFDLFVBQUQ7TUFDRSxPQUFPLEdBQUcsT0FBTyxHQUFHO01BQ3BCLFdBQVcsTUFBTTtPQUNmLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixFQUFFLE9BQU8sTUFBTSxNQUFNLEdBQUc7T0FDMUQsVUFBVSxTQUFTO09BQ25CLGFBQWEsWUFBOEI7T0FDM0MsUUFBUSxDQUFDO01BQ1g7TUFDQSxXQUFVO2dCQVJaO09BVUUsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQWlCO09BQW9COzs7OztPQUNuRCx3QkFBQyxVQUFEO1FBQVEsT0FBTTtrQkFBZ0I7T0FBb0I7Ozs7O09BQ2xELHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFtQjtPQUFzQjs7Ozs7T0FDdkQsd0JBQUMsVUFBRDtRQUFRLE9BQU07a0JBQW9CO09BQXNCOzs7OztNQUNsRDs7Ozs7YUFDTDs7Ozs7SUFDRjs7Ozs7O0dBR0osV0FBVyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFtQztHQUFxQjs7Ozs7R0FFaEYsU0FBUyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFtQztHQUFTOzs7OztHQUVsRSxDQUFDLFdBQVcsQ0FBQyxTQUFTLFFBQVEsV0FBVyxLQUN4Qyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUF3RjtHQUVsRzs7Ozs7R0FJSixDQUFDLFdBQVcsQ0FBQyxTQUFTLFFBQVEsU0FBUyxLQUN0QztJQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQTBCO1FBQVk7Ozs7O1FBQ3BELHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUEwQjtRQUFXOzs7OztRQUNuRCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBMEI7UUFBVTs7Ozs7UUFDbEQsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQTBCO1FBQVk7Ozs7O1FBQ3BELHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFzQztRQUFVOzs7OztPQUM1RDs7Ozs7ZUFDQzs7OztnQkFDUCx3QkFBQyxTQUFELFlBQ0csUUFBUSxLQUFJLFdBQ1gsd0JBQUMsTUFBRDtPQUFvQixXQUFVO2lCQUE5QjtRQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNYLFNBQ0Msd0JBQUMsVUFBRDtVQUFRLGVBQWUsT0FBTyxPQUFPLEVBQUU7VUFBRyxXQUFVO29CQUNqRCxPQUFPO1NBQ0Y7Ozs7b0JBRVIsT0FBTztRQUVQOzs7OztRQUNKLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNaLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO1VBQW9CLE9BQU8sT0FBTztvQkFDOUMsT0FBTztTQUNMOzs7OztRQUNIOzs7OztRQUNKLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNaLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLE9BQU87U0FDSjs7Ozs7UUFDSjs7Ozs7UUFDSix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWix3QkFBQyxRQUFEO1VBQU0sV0FBVzswQkFDWixPQUFPLHNCQUFzQixVQUFVLE9BQU8sc0JBQXNCLGFBQWMsNEJBQ25GLE9BQU8sc0JBQXNCLFdBQVcsa0NBQ3hDO29CQUNELE9BQU87U0FDSjs7Ozs7UUFDSjs7Ozs7UUFDSix3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWix3QkFBQyxVQUFEO1VBQ0UsZUFBZSxVQUFVLE9BQU8sT0FBTyxFQUFFO1VBQ3pDLFdBQVU7b0JBQ1g7U0FFTzs7Ozs7UUFDTjs7Ozs7T0FDRjtTQXBDSyxPQUFPOzs7O2FBb0NaLENBQ0wsRUFDSTs7OztjQUNGOzs7Ozs7SUFDSjs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLFFBQVEsS0FBSSxXQUNYLHdCQUFDLE9BQUQ7TUFBcUIsV0FBVTtnQkFBL0I7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNHLFNBQ0Msd0JBQUMsVUFBRDtTQUFRLGVBQWUsT0FBTyxPQUFPLEVBQUU7U0FBRyxXQUFVO21CQUNqRCxPQUFPO1FBQ0Y7Ozs7bUJBRVIsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQStCLE9BQU87UUFBbUI7Ozs7a0JBRTNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFXOzBCQUNSLE9BQU8sc0JBQXNCLFVBQVUsT0FBTyxzQkFBc0IsYUFBYyw0QkFDbkYsT0FBTyxzQkFBc0IsV0FBVyxrQ0FDeEM7bUJBQ0wsT0FBTztRQUNKOzs7O2dCQUNIOzs7Ozs7T0FDTCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtRQUE4QyxPQUFPLE9BQU87a0JBQ3RFLE9BQU87T0FDUDs7Ozs7T0FDSCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUFvRyxZQUN6RixPQUFPLE1BQ1o7Ozs7O2tCQUNOLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLFVBQVUsT0FBTyxPQUFPLEVBQUU7U0FDekMsV0FBVTttQkFDWDtRQUVPOzs7O2dCQUNMOzs7Ozs7TUFDRjtRQTlCSyxPQUFPOzs7O1lBOEJaLENBQ047SUFDRTs7Ozs7SUFHSixRQUNDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEI7T0FBcUQ7T0FDdEMsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWlDLEtBQUs7T0FBVzs7Ozs7T0FBQztPQUFJLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUErQixLQUFLO09BQWlCOzs7OztPQUN2SjtPQUFJO09BQVEsS0FBSztPQUFNO01BQ3BCOzs7OztlQUNOLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUNFLFNBQVM7T0FDVCxVQUFVLFNBQVM7T0FDbkIsV0FBVTtPQUNWLGNBQVc7aUJBQ1o7TUFFTzs7OztnQkFDUix3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFVBQVUsU0FBUyxLQUFLLGNBQWMsS0FBSyxlQUFlO09BQzFELFdBQVU7T0FDVixjQUFXO2lCQUNaO01BRU87Ozs7Y0FDTDs7Ozs7YUFDRjs7Ozs7O0dBRVA7Ozs7O0VBRUQ7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk15VGlja2V0cy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBnZXRUaWNrZXRzLCBnZXRDYXRlZ29yaWVzIH0gZnJvbSAnLi4vYXBpJztcblxuaW50ZXJmYWNlIFRpY2tldCB7XG4gIGlkOiBzdHJpbmc7XG4gIHRpY2tldE51bWJlcjogc3RyaW5nO1xuICBzdW1tYXJ5OiBzdHJpbmc7XG4gIHN0YXR1czogc3RyaW5nO1xuICByZXF1ZXN0ZWRQcmlvcml0eTogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgQ2F0ZWdvcnkge1xuICBpZDogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBNZXRhZGF0YSB7XG4gIHBhZ2U6IG51bWJlcjtcbiAgbGltaXQ6IG51bWJlcjtcbiAgdG90YWw6IG51bWJlcjtcbiAgdG90YWxQYWdlczogbnVtYmVyO1xufVxuXG5pbnRlcmZhY2UgUHJvcHMge1xuICBvblZpZXc/OiAodGlja2V0SWQ6IHN0cmluZykgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IE15VGlja2V0czogUmVhY3QuRkM8UHJvcHM+ID0gKHsgb25WaWV3IH0pID0+IHtcbiAgY29uc3QgW3RpY2tldHMsIHNldFRpY2tldHNdID0gdXNlU3RhdGU8VGlja2V0W10+KFtdKTtcbiAgY29uc3QgW2NhdGVnb3JpZXMsIHNldENhdGVnb3JpZXNdID0gdXNlU3RhdGU8Q2F0ZWdvcnlbXT4oW10pO1xuICBjb25zdCBbbWV0YSwgc2V0TWV0YV0gPSB1c2VTdGF0ZTxNZXRhZGF0YSB8IG51bGw+KG51bGwpO1xuICBcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIFxuICAvLyBTdGF0ZXMgZm9yIHBhZ2luYXRpb24gYW5kIGZpbHRlcnNcbiAgY29uc3QgW3BhZ2UsIHNldFBhZ2VdID0gdXNlU3RhdGUoMSk7XG4gIGNvbnN0IFtzZWFyY2gsIHNldFNlYXJjaF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtjYXRlZ29yeUlkLCBzZXRDYXRlZ29yeUlkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3ByaW9yaXR5LCBzZXRQcmlvcml0eV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtzdGF0dXMsIHNldFN0YXR1c10gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtzb3J0QnksIHNldFNvcnRCeV0gPSB1c2VTdGF0ZSgnY3JlYXRlZEF0Jyk7XG4gIGNvbnN0IFtzb3J0T3JkZXIsIHNldFNvcnRPcmRlcl0gPSB1c2VTdGF0ZTwnYXNjJyB8ICdkZXNjJz4oJ2Rlc2MnKTtcblxuICAvLyBEZWJvdW5jZSBzZWFyY2ggc3RhdGVcbiAgY29uc3QgW2RlYm91bmNlZFNlYXJjaCwgc2V0RGVib3VuY2VkU2VhcmNoXSA9IHVzZVN0YXRlKCcnKTtcblxuICAvLyBGZXRjaCBjYXRlZ29yaWVzIG9uIG1vdW50XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgZmV0Y2hDYXRzID0gYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGdldENhdGVnb3JpZXMoKTtcbiAgICAgICAgc2V0Q2F0ZWdvcmllcyhkYXRhKTtcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gbG9hZCBjYXRlZ29yaWVzIGZvciBmaWx0ZXInLCBlcnIpO1xuICAgICAgfVxuICAgIH07XG4gICAgZmV0Y2hDYXRzKCk7XG4gIH0sIFtdKTtcblxuICAvLyBIYW5kbGUgU2VhcmNoIERlYm91bmNlXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgdGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHNldERlYm91bmNlZFNlYXJjaChzZWFyY2gpO1xuICAgICAgc2V0UGFnZSgxKTsgLy8gUmVzZXQgcGFnZSBvbiBuZXcgc2VhcmNoXG4gICAgfSwgNTAwKTtcbiAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKTtcbiAgfSwgW3NlYXJjaF0pO1xuXG4gIC8vIEhhbmRsZSBGaWx0ZXIgQ2hhbmdlcyAocmVzZXQgcGFnZSlcbiAgY29uc3QgaGFuZGxlRmlsdGVyQ2hhbmdlID0gKHNldHRlcjogUmVhY3QuRGlzcGF0Y2g8UmVhY3QuU2V0U3RhdGVBY3Rpb248YW55Pj4sIHZhbHVlOiBhbnkpID0+IHtcbiAgICBzZXR0ZXIodmFsdWUpO1xuICAgIHNldFBhZ2UoMSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2xlYXJGaWx0ZXJzID0gKCkgPT4ge1xuICAgIHNldFNlYXJjaCgnJyk7XG4gICAgc2V0Q2F0ZWdvcnlJZCgnJyk7XG4gICAgc2V0UHJpb3JpdHkoJycpO1xuICAgIHNldFN0YXR1cygnJyk7XG4gICAgc2V0U29ydEJ5KCdjcmVhdGVkQXQnKTtcbiAgICBzZXRTb3J0T3JkZXIoJ2Rlc2MnKTtcbiAgICBzZXRQYWdlKDEpO1xuICB9O1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZmV0Y2hUaWNrZXRzKCk7XG4gIH0sIFtwYWdlLCBkZWJvdW5jZWRTZWFyY2gsIGNhdGVnb3J5SWQsIHByaW9yaXR5LCBzdGF0dXMsIHNvcnRCeSwgc29ydE9yZGVyXSk7XG5cbiAgY29uc3QgZmV0Y2hUaWNrZXRzID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldExvYWRpbmcodHJ1ZSk7XG4gICAgc2V0RXJyb3IobnVsbCk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZ2V0VGlja2V0cyh7XG4gICAgICAgIHBhZ2UsXG4gICAgICAgIGxpbWl0OiAxMCxcbiAgICAgICAgc2VhcmNoOiBkZWJvdW5jZWRTZWFyY2ggfHwgdW5kZWZpbmVkLFxuICAgICAgICBjYXRlZ29yeUlkOiBjYXRlZ29yeUlkIHx8IHVuZGVmaW5lZCxcbiAgICAgICAgcHJpb3JpdHk6IHByaW9yaXR5IHx8IHVuZGVmaW5lZCxcbiAgICAgICAgc3RhdHVzOiBzdGF0dXMgfHwgdW5kZWZpbmVkLFxuICAgICAgICBzb3J0QnksXG4gICAgICAgIHNvcnRPcmRlclxuICAgICAgfSk7XG4gICAgICBzZXRUaWNrZXRzKHJlc3BvbnNlLmRhdGEpO1xuICAgICAgc2V0TWV0YShyZXNwb25zZS5tZXRhKTtcbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UgfHwgJ0FuIGVycm9yIG9jY3VycmVkIHdoaWxlIGZldGNoaW5nIHRpY2tldHMuJyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVOZXh0ID0gKCkgPT4ge1xuICAgIGlmIChtZXRhICYmIHBhZ2UgPCBtZXRhLnRvdGFsUGFnZXMpIHNldFBhZ2UocGFnZSArIDEpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVByZXYgPSAoKSA9PiB7XG4gICAgaWYgKHBhZ2UgPiAxKSBzZXRQYWdlKHBhZ2UgLSAxKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTYgbXQtNlwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBtZDppdGVtcy1jZW50ZXIgbWItNlwiPlxuICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBtYi00IG1kOm1iLTBcIj5NeSBUaWNrZXRzPC9oMz5cbiAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDbGVhckZpbHRlcnN9XG4gICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbSBweC00IHB5LTIgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCByb3VuZGVkIHRleHQtZ3JheS02MDAgaG92ZXI6YmctZ3JheS01MCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgID5cbiAgICAgICAgICBDbGVhciBGaWx0ZXJzXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBDb250cm9sIEJhcjogU2VhcmNoIGFuZCBGaWx0ZXJzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGxnOmdyaWQtY29scy02IGdhcC00IG1iLTYgYmctemVuUGFsZSBwLTQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXplblByaW1hcnkvMjBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1iLTFcIj5TZWFyY2g8L2xhYmVsPlxuICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCIgXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBUaWNrZXQgIyBvciBTdW1tYXJ5Li4uXCIgXG4gICAgICAgICAgICB2YWx1ZT17c2VhcmNofVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2goZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLXplblByaW1hcnkgdGV4dC1zbVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIFxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTYwMCBtYi0xXCI+Q2F0ZWdvcnk8L2xhYmVsPlxuICAgICAgICAgIDxzZWxlY3QgXG4gICAgICAgICAgICB2YWx1ZT17Y2F0ZWdvcnlJZH0gXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUZpbHRlckNoYW5nZShzZXRDYXRlZ29yeUlkLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctemVuUHJpbWFyeSB0ZXh0LXNtIGJnLXdoaXRlXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiXCI+QWxsIENhdGVnb3JpZXM8L29wdGlvbj5cbiAgICAgICAgICAgIHtjYXRlZ29yaWVzLm1hcChjID0+IChcbiAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e2MuaWR9IHZhbHVlPXtjLmlkfT57Yy5uYW1lfTwvb3B0aW9uPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1iLTFcIj5Qcmlvcml0eTwvbGFiZWw+XG4gICAgICAgICAgPHNlbGVjdCBcbiAgICAgICAgICAgIHZhbHVlPXtwcmlvcml0eX0gXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUZpbHRlckNoYW5nZShzZXRQcmlvcml0eSwgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLXplblByaW1hcnkgdGV4dC1zbSBiZy13aGl0ZVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBQcmlvcml0aWVzPC9vcHRpb24+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTG93XCI+TG93PC9vcHRpb24+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiTWVkaXVtXCI+TWVkaXVtPC9vcHRpb24+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiSGlnaFwiPkhpZ2g8L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJDcml0aWNhbFwiPkNyaXRpY2FsPC9vcHRpb24+XG4gICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1iLTFcIj5TdGF0dXM8L2xhYmVsPlxuICAgICAgICAgIDxzZWxlY3QgXG4gICAgICAgICAgICB2YWx1ZT17c3RhdHVzfSBcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsdGVyQ2hhbmdlKHNldFN0YXR1cywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMSBmb2N1czpyaW5nLXplblByaW1hcnkgdGV4dC1zbSBiZy13aGl0ZVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPkFsbCBTdGF0dXNlczwvb3B0aW9uPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk5ld1wiPk5ldzwvb3B0aW9uPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkluIFByb2dyZXNzXCI+SW4gUHJvZ3Jlc3M8L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJSZXNvbHZlZFwiPlJlc29sdmVkPC9vcHRpb24+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiQ2xvc2VkXCI+Q2xvc2VkPC9vcHRpb24+XG4gICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktNjAwIG1iLTFcIj5Tb3J0IEJ5PC9sYWJlbD5cbiAgICAgICAgICA8c2VsZWN0IFxuICAgICAgICAgICAgdmFsdWU9e2Ake3NvcnRCeX0tJHtzb3J0T3JkZXJ9YH0gXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgW25ld1NvcnRCeSwgbmV3U29ydE9yZGVyXSA9IGUudGFyZ2V0LnZhbHVlLnNwbGl0KCctJyk7XG4gICAgICAgICAgICAgIHNldFNvcnRCeShuZXdTb3J0QnkpO1xuICAgICAgICAgICAgICBzZXRTb3J0T3JkZXIobmV3U29ydE9yZGVyIGFzICdhc2MnIHwgJ2Rlc2MnKTtcbiAgICAgICAgICAgICAgc2V0UGFnZSgxKTtcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0xIGZvY3VzOnJpbmctemVuUHJpbWFyeSB0ZXh0LXNtIGJnLXdoaXRlXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY3JlYXRlZEF0LWRlc2NcIj5OZXdlc3QgRmlyc3Q8L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjcmVhdGVkQXQtYXNjXCI+T2xkZXN0IEZpcnN0PC9vcHRpb24+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwidGlja2V0TnVtYmVyLWFzY1wiPlRpY2tldCAjIChBLVopPC9vcHRpb24+XG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwidGlja2V0TnVtYmVyLWRlc2NcIj5UaWNrZXQgIyAoWi1BKTwvb3B0aW9uPlxuICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgXG4gICAgICB7LyogTG9hZGluZyAmIEVycm9yIFN0YXRlcyAqL31cbiAgICAgIHtsb2FkaW5nICYmIDxwIGNsYXNzTmFtZT1cInRleHQtemVuUHJpbWFyeSBmb250LW1lZGl1bSBweS00XCI+TG9hZGluZyB0aWNrZXRzLi4uPC9wPn1cbiAgICAgIFxuICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTcwMCBmb250LXNlbWlib2xkIG1iLTRcIj57ZXJyb3J9PC9wPn1cbiAgICAgIFxuICAgICAgeyFsb2FkaW5nICYmICFlcnJvciAmJiB0aWNrZXRzLmxlbmd0aCA9PT0gMCAmJiAoXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS01MDAgYmctZ3JheS01MCBwLTggcm91bmRlZCB0ZXh0LWNlbnRlciBib3JkZXIgYm9yZGVyLWRhc2hlZCBib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICBObyB0aWNrZXRzIGZvdW5kIG1hdGNoaW5nIHlvdXIgY3JpdGVyaWEuXG4gICAgICAgIDwvcD5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBUaWNrZXQgTGlzdCAqL31cbiAgICAgIHshbG9hZGluZyAmJiAhZXJyb3IgJiYgdGlja2V0cy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgPD5cbiAgICAgICAgICB7LyogRGVza3RvcCBUYWJsZSBWaWV3ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIG1kOmJsb2NrIG92ZXJmbG93LXgtYXV0b1wiPlxuICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgYm9yZGVyLWNvbGxhcHNlXCI+XG4gICAgICAgICAgICAgIDx0aGVhZD5cbiAgICAgICAgICAgICAgICA8dHIgY2xhc3NOYW1lPVwiYmctemVuQmcgdGV4dC1ncmF5LTcwMCBib3JkZXItYi0yIGJvcmRlci16ZW5QcmltYXJ5XCI+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00IGZvbnQtc2VtaWJvbGRcIj5UaWNrZXQgIzwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00IGZvbnQtc2VtaWJvbGRcIj5TdW1tYXJ5PC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTQgZm9udC1zZW1pYm9sZFwiPlN0YXR1czwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00IGZvbnQtc2VtaWJvbGRcIj5Qcmlvcml0eTwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC00IGZvbnQtc2VtaWJvbGQgdGV4dC1jZW50ZXJcIj5BY3Rpb248L3RoPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgIDx0Ym9keT5cbiAgICAgICAgICAgICAgICB7dGlja2V0cy5tYXAodGlja2V0ID0+IChcbiAgICAgICAgICAgICAgICAgIDx0ciBrZXk9e3RpY2tldC5pZH0gY2xhc3NOYW1lPVwiYm9yZGVyLWIgaG92ZXI6YmctemVuUGFsZSB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00IHRleHQtemVuU2Vjb25kYXJ5IGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAge29uVmlldyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gb25WaWV3KHRpY2tldC5pZCl9IGNsYXNzTmFtZT1cImhvdmVyOnVuZGVybGluZSBob3Zlcjp0ZXh0LXplblByaW1hcnlcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3RpY2tldC50aWNrZXROdW1iZXJ9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgdGlja2V0LnRpY2tldE51bWJlclxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTQgdGV4dC1ncmF5LTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHJ1bmNhdGUgbWF4LXcteHNcIiB0aXRsZT17dGlja2V0LnN1bW1hcnl9PlxuICAgICAgICAgICAgICAgICAgICAgICAge3RpY2tldC5zdW1tYXJ5fVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC00XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWJsb2NrIGJnLXplbkJnIHRleHQtZ3JheS03MDAgcHgtMiBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LXNtIGJvcmRlciBib3JkZXItZ3JheS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHt0aWNrZXQuc3RhdHVzfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1ibG9jayBweC0yIHB5LTEgcm91bmRlZC1mdWxsIHRleHQtc20gZm9udC1zZW1pYm9sZFxuICAgICAgICAgICAgICAgICAgICAgICAgJHsodGlja2V0LnJlcXVlc3RlZFByaW9yaXR5ID09PSAnSGlnaCcgfHwgdGlja2V0LnJlcXVlc3RlZFByaW9yaXR5ID09PSAnQ3JpdGljYWwnKSA/ICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCcgOiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGlja2V0LnJlcXVlc3RlZFByaW9yaXR5ID09PSAnTWVkaXVtJyA/ICdiZy15ZWxsb3ctMTAwIHRleHQteWVsbG93LTgwMCcgOiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dGlja2V0LnJlcXVlc3RlZFByaW9yaXR5fVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtNCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblZpZXcgJiYgb25WaWV3KHRpY2tldC5pZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXplblByaW1hcnkgaG92ZXI6dGV4dC13aGl0ZSBib3JkZXIgYm9yZGVyLXplblByaW1hcnkgaG92ZXI6YmctemVuUHJpbWFyeSBweC0zIHB5LTEgcm91bmRlZCB0cmFuc2l0aW9uLWNvbG9ycyB0ZXh0LXNtIGZvbnQtbWVkaXVtXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICBWaWV3XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBNb2JpbGUgQ2FyZCBWaWV3ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWQ6aGlkZGVuIHNwYWNlLXktNFwiPlxuICAgICAgICAgICAge3RpY2tldHMubWFwKHRpY2tldCA9PiAoXG4gICAgICAgICAgICAgIDxkaXYga2V5PXt0aWNrZXQuaWR9IGNsYXNzTmFtZT1cImJvcmRlciByb3VuZGVkLWxnIHAtNCBiZy13aGl0ZSBzaGFkb3ctc20gaG92ZXI6c2hhZG93LW1kIHRyYW5zaXRpb24tc2hhZG93XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICB7b25WaWV3ID8gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG9uVmlldyh0aWNrZXQuaWQpfSBjbGFzc05hbWU9XCJ0ZXh0LXplblNlY29uZGFyeSBmb250LWJvbGQgaG92ZXI6dW5kZXJsaW5lXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3RpY2tldC50aWNrZXROdW1iZXJ9XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC16ZW5TZWNvbmRhcnkgZm9udC1ib2xkXCI+e3RpY2tldC50aWNrZXROdW1iZXJ9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1ibG9jayBweC0yIHB5LTEgcm91bmRlZC1mdWxsIHRleHQteHMgZm9udC1zZW1pYm9sZFxuICAgICAgICAgICAgICAgICAgICAgICAgJHsodGlja2V0LnJlcXVlc3RlZFByaW9yaXR5ID09PSAnSGlnaCcgfHwgdGlja2V0LnJlcXVlc3RlZFByaW9yaXR5ID09PSAnQ3JpdGljYWwnKSA/ICdiZy1yZWQtMTAwIHRleHQtcmVkLTgwMCcgOiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGlja2V0LnJlcXVlc3RlZFByaW9yaXR5ID09PSAnTWVkaXVtJyA/ICdiZy15ZWxsb3ctMTAwIHRleHQteWVsbG93LTgwMCcgOiBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgJ2JnLWdyZWVuLTEwMCB0ZXh0LWdyZWVuLTgwMCd9YH0+XG4gICAgICAgICAgICAgICAgICAgIHt0aWNrZXQucmVxdWVzdGVkUHJpb3JpdHl9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMCBmb250LW1lZGl1bSBtYi0zIGxpbmUtY2xhbXAtMlwiIHRpdGxlPXt0aWNrZXQuc3VtbWFyeX0+XG4gICAgICAgICAgICAgICAgICB7dGlja2V0LnN1bW1hcnl9XG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBiZy16ZW5CZyB0ZXh0LWdyYXktNzAwIHB4LTIgcHktMSByb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci1ncmF5LTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICBTdGF0dXM6IHt0aWNrZXQuc3RhdHVzfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25WaWV3ICYmIG9uVmlldyh0aWNrZXQuaWQpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXplblByaW1hcnkgZm9udC1zZW1pYm9sZCBob3Zlcjp1bmRlcmxpbmVcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBWaWV3IERldGFpbFxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUGFnaW5hdGlvbiAqL31cbiAgICAgICAgICB7bWV0YSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtdC02IHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTYwMCBtYi00IHNtOm1iLTBcIj5cbiAgICAgICAgICAgICAgICBTaG93aW5nIHBhZ2UgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXplblByaW1hcnlcIj57bWV0YS5wYWdlfTwvc3Bhbj4gb2YgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LWdyYXktODAwXCI+e21ldGEudG90YWxQYWdlc308L3NwYW4+IFxuICAgICAgICAgICAgICAgIHsnICd9KFRvdGFsIHttZXRhLnRvdGFsfSB0aWNrZXRzKVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzcGFjZS14LTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlUHJldn0gXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17cGFnZSA9PT0gMX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBib3JkZXIgcm91bmRlZC1tZCB0ZXh0LWdyYXktNjAwIGJnLXdoaXRlIGhvdmVyOmJnLXplblBhbGUgaG92ZXI6dGV4dC16ZW5QcmltYXJ5IGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHRyYW5zaXRpb24tY29sb3JzIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXplblByaW1hcnkgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJQcmV2aW91cyBwYWdlXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBQcmV2aW91c1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVOZXh0fSBcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtwYWdlID09PSBtZXRhLnRvdGFsUGFnZXMgfHwgbWV0YS50b3RhbFBhZ2VzID09PSAwfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJvcmRlciByb3VuZGVkLW1kIHRleHQtd2hpdGUgYmctemVuUHJpbWFyeSBob3ZlcjpiZy16ZW5TZWNvbmRhcnkgZGlzYWJsZWQ6YmctZ3JheS00MDAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHRyYW5zaXRpb24tY29sb3JzIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLW9mZnNldC0xIGZvY3VzOnJpbmctemVuUHJpbWFyeSBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIk5leHQgcGFnZVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgTmV4dFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=