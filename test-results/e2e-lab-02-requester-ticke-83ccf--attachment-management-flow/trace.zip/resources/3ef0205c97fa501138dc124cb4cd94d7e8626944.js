import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CreateTicket.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=15734ece";
import { getCategories, getRelatedSystems, createTicket, uploadAttachmentToTicket } from "/src/api.ts";
var _jsxFileName = "C:/Users/meebo/toktickit/client/src/components/CreateTicket.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=15734ece";
var _s = $RefreshSig$();
export const CreateTicket = ({ onCancel, onSuccess }) => {
	_s();
	const [categories, setCategories] = useState([]);
	const [systems, setSystems] = useState([]);
	const [categoryId, setCategoryId] = useState("");
	const [relatedSystemId, setRelatedSystemId] = useState("");
	const [priority, setPriority] = useState("Medium");
	const [summary, setSummary] = useState("");
	const [description, setDescription] = useState("");
	const [file, setFile] = useState(null);
	const [loading, setLoading] = useState(false);
	const [initLoading, setInitLoading] = useState(true);
	const [error, setError] = useState(null);
	useEffect(() => {
		const fetchOptions = async () => {
			try {
				const [catData, sysData] = await Promise.all([getCategories(), getRelatedSystems()]);
				setCategories(catData);
				setSystems(sysData);
			} catch (err) {
				setError(err.message || "Failed to load options");
			} finally {
				setInitLoading(false);
			}
		};
		fetchOptions();
	}, []);
	const handleFileChange = (e) => {
		if (e.target.files && e.target.files[0]) {
			setFile(e.target.files[0]);
		}
	};
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!categoryId || !relatedSystemId || !summary.trim() || !description.trim()) {
			setError("Please fill in all required fields (including Description).");
			return;
		}
		setLoading(true);
		setError(null);
		try {
			const ticketPayload = {
				categoryId,
				relatedSystemId,
				requestedPriority: priority,
				summary: summary.trim(),
				description: description.trim()
			};
			const newTicket = await createTicket(ticketPayload);
			if (file) {
				await uploadAttachmentToTicket(newTicket.id, file);
			}
			onSuccess();
		} catch (err) {
			setError(err.message || "An error occurred while submitting.");
		} finally {
			setLoading(false);
		}
	};
	if (initLoading) return /* @__PURE__ */ _jsxDEV("div", {
		className: "p-6 text-zenPrimary font-medium",
		children: "Loading form..."
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 90,
		columnNumber: 27
	}, this);
	// ถ้าโหลด Categories หรือ Systems ไม่ผ่าน ไม่ควรพยายามเรนเดอร์ฟอร์ม
	if (error && (categories.length === 0 || systems.length === 0)) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-6 max-w-2xl mx-auto text-center",
			children: [
				/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xl font-bold text-gray-800 mb-4",
					children: "Error Loading Form"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-red-600 mb-6 font-medium",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onCancel,
					className: "bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-6 py-2 rounded shadow-sm transition-colors",
					children: "Go Back"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 98,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 95,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-6 max-w-2xl mx-auto text-left",
		children: [
			/* @__PURE__ */ _jsxDEV("h3", {
				className: "text-xl font-bold text-gray-800 mb-6 border-b pb-2 border-zenPrimary",
				children: "Create New Ticket"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 110,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-red-100 text-red-800 p-3 rounded mb-4",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 112,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-sm font-semibold text-gray-700 mb-1",
						children: ["Category ", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-red-500",
							children: "*"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 117,
							columnNumber: 86
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						value: categoryId,
						onChange: (e) => setCategoryId(e.target.value),
						className: "w-full border border-gray-300 rounded p-2 focus:ring-2 focus:ring-zenPrimary focus:outline-none",
						required: true,
						children: [/* @__PURE__ */ _jsxDEV("option", {
							value: "",
							children: "-- Select Category --"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 13
						}, this), categories.map((cat) => /* @__PURE__ */ _jsxDEV("option", {
							value: cat.id,
							children: cat.name
						}, cat.id, false, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 15
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 116,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-sm font-semibold text-gray-700 mb-1",
						children: ["Related System ", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-red-500",
							children: "*"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 92
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 132,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						value: relatedSystemId,
						onChange: (e) => setRelatedSystemId(e.target.value),
						className: "w-full border border-gray-300 rounded p-2 focus:ring-2 focus:ring-zenPrimary focus:outline-none",
						required: true,
						children: [/* @__PURE__ */ _jsxDEV("option", {
							value: "",
							children: "-- Select System --"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 13
						}, this), systems.map((sys) => /* @__PURE__ */ _jsxDEV("option", {
							value: sys.id,
							children: sys.name
						}, sys.id, false, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 15
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-sm font-semibold text-gray-700 mb-1",
						children: "Priority"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 147,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("select", {
						value: priority,
						onChange: (e) => setPriority(e.target.value),
						className: "w-full border border-gray-300 rounded p-2 focus:ring-2 focus:ring-zenPrimary focus:outline-none",
						children: [
							/* @__PURE__ */ _jsxDEV("option", {
								value: "Low",
								children: "Low"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "Medium",
								children: "Medium"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("option", {
								value: "High",
								children: "High"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 146,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-sm font-semibold text-gray-700 mb-1",
						children: ["Summary ", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-red-500",
							children: "*"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 160,
							columnNumber: 85
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 160,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						maxLength: 100,
						value: summary,
						onChange: (e) => setSummary(e.target.value),
						className: "w-full border border-gray-300 rounded p-2 focus:ring-2 focus:ring-zenPrimary focus:outline-none",
						placeholder: "Brief summary of the issue (Max 100 chars)",
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 161,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 159,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-sm font-semibold text-gray-700 mb-1",
						children: ["Description ", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-red-500",
							children: "*"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 173,
							columnNumber: 89
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 173,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("textarea", {
						maxLength: 1e3,
						rows: 4,
						value: description,
						onChange: (e) => setDescription(e.target.value),
						className: "w-full border border-gray-300 rounded p-2 focus:ring-2 focus:ring-zenPrimary focus:outline-none",
						placeholder: "Detailed description...",
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 174,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-sm font-semibold text-gray-700 mb-1",
							children: "Attachment"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 186,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("input", {
							type: "file",
							accept: "image/*,application/pdf",
							onChange: handleFileChange,
							className: "w-full border border-gray-300 rounded p-2 focus:outline-none text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-zenPale file:text-zenPrimary hover:file:bg-zenPrimary hover:file:text-white"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 187,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-gray-500 mt-1",
							children: "Accepted formats: Images or PDF. Max 5MB."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 193,
							columnNumber: 11
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 185,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex space-x-3 pt-4 border-t border-gray-200",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: loading,
							className: "bg-zenPrimary hover:bg-zenSecondary text-white px-6 py-2 rounded shadow-sm disabled:opacity-50 transition-colors",
							children: loading ? "Submitting..." : "Submit Ticket"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 197,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: onCancel,
							disabled: loading,
							className: "bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-6 py-2 rounded shadow-sm transition-colors",
							children: "Cancel"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 204,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 196,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 114,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 109,
		columnNumber: 5
	}, this);
};
_s(CreateTicket, "OMrGaKJwFHZvo6aVF/5L8ipB+90=");
_c = CreateTicket;
var _c;
$RefreshReg$(_c, "CreateTicket");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/CreateTicket.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/meebo/toktickit/client/src/components/CreateTicket.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/meebo/toktickit/client/src/components/CreateTicket.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/meebo/toktickit/client/src/components/CreateTicket.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsZUFBZSxtQkFBbUIsY0FBYyxnQ0FBZ0M7Ozs7QUFpQnpGLE9BQU8sTUFBTSxnQkFBaUMsRUFBRSxVQUFVLGdCQUFnQjs7Q0FDeEUsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQXFCLENBQUMsQ0FBQztDQUMzRCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQTBCLENBQUMsQ0FBQztDQUUxRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxFQUFFO0NBQy9DLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsRUFBRTtDQUN6RCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsUUFBUTtDQUNqRCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUN6QyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBQ2pELE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBc0IsSUFBSTtDQUVsRCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxJQUFJO0NBQ25ELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBd0IsSUFBSTtDQUV0RCxnQkFBZ0I7RUFDZCxNQUFNLGVBQWUsWUFBWTtHQUMvQixJQUFJO0lBQ0YsTUFBTSxDQUFDLFNBQVMsV0FBVyxNQUFNLFFBQVEsSUFBSSxDQUMzQyxjQUFjLEdBQ2Qsa0JBQWtCLENBQ3BCLENBQUM7SUFDRCxjQUFjLE9BQU87SUFDckIsV0FBVyxPQUFPO0dBQ3BCLFNBQVMsS0FBVTtJQUNqQixTQUFTLElBQUksV0FBVyx3QkFBd0I7R0FDbEQsVUFBVTtJQUNSLGVBQWUsS0FBSztHQUN0QjtFQUNGO0VBQ0EsYUFBYTtDQUNmLEdBQUcsQ0FBQyxDQUFDO0NBRUwsTUFBTSxvQkFBb0IsTUFBMkM7RUFDbkUsSUFBSSxFQUFFLE9BQU8sU0FBUyxFQUFFLE9BQU8sTUFBTSxJQUFJO0dBQ3ZDLFFBQVEsRUFBRSxPQUFPLE1BQU0sRUFBRTtFQUMzQjtDQUNGO0NBRUEsTUFBTSxlQUFlLE9BQU8sTUFBdUI7RUFDakQsRUFBRSxlQUFlO0VBQ2pCLElBQUksQ0FBQyxjQUFjLENBQUMsbUJBQW1CLENBQUMsUUFBUSxLQUFLLEtBQUssQ0FBQyxZQUFZLEtBQUssR0FBRztHQUM3RSxTQUFTLDZEQUE2RDtHQUN0RTtFQUNGO0VBRUEsV0FBVyxJQUFJO0VBQ2YsU0FBUyxJQUFJO0VBQ2IsSUFBSTtHQUNGLE1BQU0sZ0JBQWdCO0lBQ3BCO0lBQ0E7SUFDQSxtQkFBbUI7SUFDbkIsU0FBUyxRQUFRLEtBQUs7SUFDdEIsYUFBYSxZQUFZLEtBQUs7R0FDaEM7R0FFQSxNQUFNLFlBQVksTUFBTSxhQUFhLGFBQWE7R0FFbEQsSUFBSSxNQUFNO0lBQ1IsTUFBTSx5QkFBeUIsVUFBVSxJQUFJLElBQUk7R0FDbkQ7R0FFQSxVQUFVO0VBQ1osU0FBUyxLQUFVO0dBQ2pCLFNBQVMsSUFBSSxXQUFXLHFDQUFxQztFQUMvRCxVQUFVO0dBQ1IsV0FBVyxLQUFLO0VBQ2xCO0NBQ0Y7Q0FFQSxJQUFJLGFBQWEsT0FBTyx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFrQztDQUFvQjs7Ozs7O0NBRzdGLElBQUksVUFBVSxXQUFXLFdBQVcsS0FBSyxRQUFRLFdBQVcsSUFBSTtFQUM5RCxPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUF1QztJQUFzQjs7Ozs7SUFDM0Usd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBaUM7SUFBUzs7Ozs7SUFDdkQsd0JBQUMsVUFBRDtLQUNFLFNBQVM7S0FDVCxXQUFVO2VBQ1g7SUFFTzs7Ozs7R0FDTDs7Ozs7O0NBRVQ7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxNQUFEO0lBQUksV0FBVTtjQUF1RTtHQUFxQjs7Ozs7R0FFekcsU0FBUyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUE0QztHQUFXOzs7OztHQUVoRix3QkFBQyxRQUFEO0lBQU0sVUFBVTtJQUFjLFdBQVU7Y0FBeEM7S0FFRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCLENBQWtFLGFBQVMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWU7TUFBTzs7OztjQUFROzs7OztlQUN6SCx3QkFBQyxVQUFEO01BQ0UsT0FBTztNQUNQLFdBQVcsTUFBTSxjQUFjLEVBQUUsT0FBTyxLQUFLO01BQzdDLFdBQVU7TUFDVjtnQkFKRixDQU1FLHdCQUFDLFVBQUQ7T0FBUSxPQUFNO2lCQUFHO01BQTZCOzs7O2dCQUM3QyxXQUFXLEtBQUksUUFDZCx3QkFBQyxVQUFEO09BQXFCLE9BQU8sSUFBSTtpQkFBSyxJQUFJO01BQWEsR0FBekMsSUFBSTs7OzthQUFxQyxDQUN2RCxDQUNLOzs7OzthQUNMOzs7OztLQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBakIsQ0FBa0UsbUJBQWUsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWU7TUFBTzs7OztjQUFROzs7OztlQUMvSCx3QkFBQyxVQUFEO01BQ0UsT0FBTztNQUNQLFdBQVcsTUFBTSxtQkFBbUIsRUFBRSxPQUFPLEtBQUs7TUFDbEQsV0FBVTtNQUNWO2dCQUpGLENBTUUsd0JBQUMsVUFBRDtPQUFRLE9BQU07aUJBQUc7TUFBMkI7Ozs7Z0JBQzNDLFFBQVEsS0FBSSxRQUNYLHdCQUFDLFVBQUQ7T0FBcUIsT0FBTyxJQUFJO2lCQUFLLElBQUk7TUFBYSxHQUF6QyxJQUFJOzs7O2FBQXFDLENBQ3ZELENBQ0s7Ozs7O2FBQ0w7Ozs7O0tBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFpRDtLQUFlOzs7O2VBQ2pGLHdCQUFDLFVBQUQ7TUFDRSxPQUFPO01BQ1AsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQUs7TUFDM0MsV0FBVTtnQkFIWjtPQUtFLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFNO09BQVc7Ozs7O09BQy9CLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFTO09BQWM7Ozs7O09BQ3JDLHdCQUFDLFVBQUQ7UUFBUSxPQUFNO2tCQUFPO09BQVk7Ozs7O01BQzNCOzs7OzthQUNMOzs7OztLQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBakIsQ0FBa0UsWUFBUSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBZTtNQUFPOzs7O2NBQVE7Ozs7O2VBQ3hILHdCQUFDLFNBQUQ7TUFDRSxNQUFLO01BQ0wsV0FBVztNQUNYLE9BQU87TUFDUCxXQUFXLE1BQU0sV0FBVyxFQUFFLE9BQU8sS0FBSztNQUMxQyxXQUFVO01BQ1YsYUFBWTtNQUNaO0tBQ0Q7Ozs7YUFDRTs7Ozs7S0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWpCLENBQWtFLGdCQUFZLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFlO01BQU87Ozs7Y0FBUTs7Ozs7ZUFDNUgsd0JBQUMsWUFBRDtNQUNFLFdBQVc7TUFDWCxNQUFNO01BQ04sT0FBTztNQUNQLFdBQVcsTUFBTSxlQUFlLEVBQUUsT0FBTyxLQUFLO01BQzlDLFdBQVU7TUFDVixhQUFZO01BQ1o7S0FDUzs7OzthQUNSOzs7OztLQUVMLHdCQUFDLE9BQUQ7TUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBaUQ7TUFBaUI7Ozs7O01BQ25GLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsUUFBTztPQUNQLFVBQVU7T0FDVixXQUFVO01BQ1g7Ozs7O01BQ0Qsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTZCO01BQTRDOzs7OztLQUNuRjs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsVUFBVTtPQUNWLFdBQVU7aUJBRVQsVUFBVSxrQkFBa0I7TUFDdkI7Ozs7Z0JBQ1Isd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxTQUFTO09BQ1QsVUFBVTtPQUNWLFdBQVU7aUJBQ1g7TUFFTzs7OztjQUNMOzs7Ozs7SUFDRDs7Ozs7O0VBQ0g7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNyZWF0ZVRpY2tldC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBnZXRDYXRlZ29yaWVzLCBnZXRSZWxhdGVkU3lzdGVtcywgY3JlYXRlVGlja2V0LCB1cGxvYWRBdHRhY2htZW50VG9UaWNrZXQgfSBmcm9tICcuLi9hcGknO1xuXG5pbnRlcmZhY2UgQ2F0ZWdvcnkge1xuICBpZDogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG59XG5cbmludGVyZmFjZSBSZWxhdGVkU3lzdGVtIHtcbiAgaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgUHJvcHMge1xuICBvbkNhbmNlbDogKCkgPT4gdm9pZDtcbiAgb25TdWNjZXNzOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgQ3JlYXRlVGlja2V0OiBSZWFjdC5GQzxQcm9wcz4gPSAoeyBvbkNhbmNlbCwgb25TdWNjZXNzIH0pID0+IHtcbiAgY29uc3QgW2NhdGVnb3JpZXMsIHNldENhdGVnb3JpZXNdID0gdXNlU3RhdGU8Q2F0ZWdvcnlbXT4oW10pO1xuICBjb25zdCBbc3lzdGVtcywgc2V0U3lzdGVtc10gPSB1c2VTdGF0ZTxSZWxhdGVkU3lzdGVtW10+KFtdKTtcbiAgXG4gIGNvbnN0IFtjYXRlZ29yeUlkLCBzZXRDYXRlZ29yeUlkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3JlbGF0ZWRTeXN0ZW1JZCwgc2V0UmVsYXRlZFN5c3RlbUlkXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3ByaW9yaXR5LCBzZXRQcmlvcml0eV0gPSB1c2VTdGF0ZSgnTWVkaXVtJyk7XG4gIGNvbnN0IFtzdW1tYXJ5LCBzZXRTdW1tYXJ5XSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2Rlc2NyaXB0aW9uLCBzZXREZXNjcmlwdGlvbl0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtmaWxlLCBzZXRGaWxlXSA9IHVzZVN0YXRlPEZpbGUgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpbml0TG9hZGluZywgc2V0SW5pdExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBmZXRjaE9wdGlvbnMgPSBhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBbY2F0RGF0YSwgc3lzRGF0YV0gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgICAgZ2V0Q2F0ZWdvcmllcygpLFxuICAgICAgICAgIGdldFJlbGF0ZWRTeXN0ZW1zKCksXG4gICAgICAgIF0pO1xuICAgICAgICBzZXRDYXRlZ29yaWVzKGNhdERhdGEpO1xuICAgICAgICBzZXRTeXN0ZW1zKHN5c0RhdGEpO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UgfHwgJ0ZhaWxlZCB0byBsb2FkIG9wdGlvbnMnKTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHNldEluaXRMb2FkaW5nKGZhbHNlKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGZldGNoT3B0aW9ucygpO1xuICB9LCBbXSk7XG5cbiAgY29uc3QgaGFuZGxlRmlsZUNoYW5nZSA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgIGlmIChlLnRhcmdldC5maWxlcyAmJiBlLnRhcmdldC5maWxlc1swXSkge1xuICAgICAgc2V0RmlsZShlLnRhcmdldC5maWxlc1swXSk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFjYXRlZ29yeUlkIHx8ICFyZWxhdGVkU3lzdGVtSWQgfHwgIXN1bW1hcnkudHJpbSgpIHx8ICFkZXNjcmlwdGlvbi50cmltKCkpIHtcbiAgICAgIHNldEVycm9yKCdQbGVhc2UgZmlsbCBpbiBhbGwgcmVxdWlyZWQgZmllbGRzIChpbmNsdWRpbmcgRGVzY3JpcHRpb24pLicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBcbiAgICBzZXRMb2FkaW5nKHRydWUpO1xuICAgIHNldEVycm9yKG51bGwpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB0aWNrZXRQYXlsb2FkID0ge1xuICAgICAgICBjYXRlZ29yeUlkLFxuICAgICAgICByZWxhdGVkU3lzdGVtSWQsXG4gICAgICAgIHJlcXVlc3RlZFByaW9yaXR5OiBwcmlvcml0eSxcbiAgICAgICAgc3VtbWFyeTogc3VtbWFyeS50cmltKCksXG4gICAgICAgIGRlc2NyaXB0aW9uOiBkZXNjcmlwdGlvbi50cmltKCksXG4gICAgICB9O1xuICAgICAgXG4gICAgICBjb25zdCBuZXdUaWNrZXQgPSBhd2FpdCBjcmVhdGVUaWNrZXQodGlja2V0UGF5bG9hZCk7XG4gICAgICBcbiAgICAgIGlmIChmaWxlKSB7XG4gICAgICAgIGF3YWl0IHVwbG9hZEF0dGFjaG1lbnRUb1RpY2tldChuZXdUaWNrZXQuaWQsIGZpbGUpO1xuICAgICAgfVxuICAgICAgXG4gICAgICBvblN1Y2Nlc3MoKTtcbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UgfHwgJ0FuIGVycm9yIG9jY3VycmVkIHdoaWxlIHN1Ym1pdHRpbmcuJyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBpZiAoaW5pdExvYWRpbmcpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInAtNiB0ZXh0LXplblByaW1hcnkgZm9udC1tZWRpdW1cIj5Mb2FkaW5nIGZvcm0uLi48L2Rpdj47XG5cbiAgLy8g4LiW4LmJ4Liy4LmC4Lir4Lil4LiUIENhdGVnb3JpZXMg4Lir4Lij4Li34LitIFN5c3RlbXMg4LmE4Lih4LmI4Lic4LmI4Liy4LiZIOC5hOC4oeC5iOC4hOC4p+C4o+C4nuC4ouC4suC4ouC4suC4oeC5gOC4o+C4meC5gOC4lOC4reC4o+C5jOC4n+C4reC4o+C5jOC4oVxuICBpZiAoZXJyb3IgJiYgKGNhdGVnb3JpZXMubGVuZ3RoID09PSAwIHx8IHN5c3RlbXMubGVuZ3RoID09PSAwKSkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC02IG10LTYgbWF4LXctMnhsIG14LWF1dG8gdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgbWItNFwiPkVycm9yIExvYWRpbmcgRm9ybTwvaDM+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMCBtYi02IGZvbnQtbWVkaXVtXCI+e2Vycm9yfTwvcD5cbiAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICBvbkNsaWNrPXtvbkNhbmNlbH1cbiAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGhvdmVyOmJnLWdyYXktNTAgdGV4dC1ncmF5LTcwMCBweC02IHB5LTIgcm91bmRlZCBzaGFkb3ctc20gdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICA+XG4gICAgICAgICAgR28gQmFja1xuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBwLTYgbXQtNiBtYXgtdy0yeGwgbXgtYXV0byB0ZXh0LWxlZnRcIj5cbiAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWdyYXktODAwIG1iLTYgYm9yZGVyLWIgcGItMiBib3JkZXItemVuUHJpbWFyeVwiPkNyZWF0ZSBOZXcgVGlja2V0PC9oMz5cbiAgICAgIFxuICAgICAge2Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwiYmctcmVkLTEwMCB0ZXh0LXJlZC04MDAgcC0zIHJvdW5kZWQgbWItNFwiPntlcnJvcn08L2Rpdj59XG5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICBcbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPkNhdGVnb3J5IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMFwiPio8L3NwYW4+PC9sYWJlbD5cbiAgICAgICAgICA8c2VsZWN0IFxuICAgICAgICAgICAgdmFsdWU9e2NhdGVnb3J5SWR9IFxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDYXRlZ29yeUlkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcC0yIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXplblByaW1hcnkgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPi0tIFNlbGVjdCBDYXRlZ29yeSAtLTwvb3B0aW9uPlxuICAgICAgICAgICAge2NhdGVnb3JpZXMubWFwKGNhdCA9PiAoXG4gICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtjYXQuaWR9IHZhbHVlPXtjYXQuaWR9PntjYXQubmFtZX08L29wdGlvbj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+UmVsYXRlZCBTeXN0ZW0gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj48L2xhYmVsPlxuICAgICAgICAgIDxzZWxlY3QgXG4gICAgICAgICAgICB2YWx1ZT17cmVsYXRlZFN5c3RlbUlkfSBcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UmVsYXRlZFN5c3RlbUlkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcC0yIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXplblByaW1hcnkgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiPi0tIFNlbGVjdCBTeXN0ZW0gLS08L29wdGlvbj5cbiAgICAgICAgICAgIHtzeXN0ZW1zLm1hcChzeXMgPT4gKFxuICAgICAgICAgICAgICA8b3B0aW9uIGtleT17c3lzLmlkfSB2YWx1ZT17c3lzLmlkfT57c3lzLm5hbWV9PC9vcHRpb24+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPlByaW9yaXR5PC9sYWJlbD5cbiAgICAgICAgICA8c2VsZWN0IFxuICAgICAgICAgICAgdmFsdWU9e3ByaW9yaXR5fSBcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UHJpb3JpdHkoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBwLTIgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctemVuUHJpbWFyeSBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJMb3dcIj5Mb3c8L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJNZWRpdW1cIj5NZWRpdW08L29wdGlvbj5cbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJIaWdoXCI+SGlnaDwvb3B0aW9uPlxuICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+U3VtbWFyeSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDBcIj4qPC9zcGFuPjwvbGFiZWw+XG4gICAgICAgICAgPGlucHV0IFxuICAgICAgICAgICAgdHlwZT1cInRleHRcIiBcbiAgICAgICAgICAgIG1heExlbmd0aD17MTAwfVxuICAgICAgICAgICAgdmFsdWU9e3N1bW1hcnl9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFN1bW1hcnkoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcm91bmRlZCBwLTIgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctemVuUHJpbWFyeSBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJCcmllZiBzdW1tYXJ5IG9mIHRoZSBpc3N1ZSAoTWF4IDEwMCBjaGFycylcIlxuICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGV4dC1ncmF5LTcwMCBtYi0xXCI+RGVzY3JpcHRpb24gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yZWQtNTAwXCI+Kjwvc3Bhbj48L2xhYmVsPlxuICAgICAgICAgIDx0ZXh0YXJlYSBcbiAgICAgICAgICAgIG1heExlbmd0aD17MTAwMH1cbiAgICAgICAgICAgIHJvd3M9ezR9XG4gICAgICAgICAgICB2YWx1ZT17ZGVzY3JpcHRpb259XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldERlc2NyaXB0aW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcC0yIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXplblByaW1hcnkgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRGV0YWlsZWQgZGVzY3JpcHRpb24uLi5cIlxuICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICA+PC90ZXh0YXJlYT5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtZ3JheS03MDAgbWItMVwiPkF0dGFjaG1lbnQ8L2xhYmVsPlxuICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgIHR5cGU9XCJmaWxlXCIgXG4gICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qLGFwcGxpY2F0aW9uL3BkZlwiXG4gICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlRmlsZUNoYW5nZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHJvdW5kZWQgcC0yIGZvY3VzOm91dGxpbmUtbm9uZSB0ZXh0LXNtIHRleHQtZ3JheS02MDAgZmlsZTptci00IGZpbGU6cHktMiBmaWxlOnB4LTQgZmlsZTpyb3VuZGVkIGZpbGU6Ym9yZGVyLTAgZmlsZTp0ZXh0LXNtIGZpbGU6Zm9udC1zZW1pYm9sZCBmaWxlOmJnLXplblBhbGUgZmlsZTp0ZXh0LXplblByaW1hcnkgaG92ZXI6ZmlsZTpiZy16ZW5QcmltYXJ5IGhvdmVyOmZpbGU6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZ3JheS01MDAgbXQtMVwiPkFjY2VwdGVkIGZvcm1hdHM6IEltYWdlcyBvciBQREYuIE1heCA1TUIuPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc3BhY2UteC0zIHB0LTQgYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwXCI+XG4gICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIiBcbiAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctemVuUHJpbWFyeSBob3ZlcjpiZy16ZW5TZWNvbmRhcnkgdGV4dC13aGl0ZSBweC02IHB5LTIgcm91bmRlZCBzaGFkb3ctc20gZGlzYWJsZWQ6b3BhY2l0eS01MCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAge2xvYWRpbmcgPyAnU3VibWl0dGluZy4uLicgOiAnU3VibWl0IFRpY2tldCd9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIiBcbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2FuY2VsfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXIgYm9yZGVyLWdyYXktMzAwIGhvdmVyOmJnLWdyYXktNTAgdGV4dC1ncmF5LTcwMCBweC02IHB5LTIgcm91bmRlZCBzaGFkb3ctc20gdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=