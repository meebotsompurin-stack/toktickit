import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DevRequesterSelector.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=15734ece";
var _jsxFileName = "C:/Users/meebo/toktickit/client/src/components/DevRequesterSelector.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=15734ece";
var _s = $RefreshSig$();
export const DevRequesterSelector = ({ onSelect }) => {
	_s();
	const [requesters, setRequesters] = useState([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	useEffect(() => {
		const fetchRequesters = async () => {
			try {
				// ยิง API ไปที่ GET /api/requesters/active ตามที่ระบุ
				const response = await fetch("/api/requesters/active");
				if (!response.ok) {
					throw new Error("Failed to fetch requesters");
				}
				const data = await response.json();
				setRequesters(data);
			} catch (err) {
				console.error("Error fetching requesters:", err);
				setError(err.message || "An error occurred");
			} finally {
				setLoading(false);
			}
		};
		fetchRequesters();
	}, []);
	const handleSelect = (requester) => {
		// 1) บันทึกลง localStorage ตามเงื่อนไข
		localStorage.setItem("toktickit_requester", JSON.stringify(requester));
		// 2) เรียก props onSelect
		onSelect(requester);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-6 max-w-2xl mx-auto",
		children: [
			/* @__PURE__ */ _jsxDEV("h3", {
				className: "text-xl font-bold text-zenPrimary mb-4",
				children: "Select Requester (Dev Mode)"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 7
			}, this),
			loading && /* @__PURE__ */ _jsxDEV("p", {
				className: "text-zenPrimary",
				children: "Loading requesters..."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 19
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "text-red-600",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 17
			}, this),
			!loading && !error && requesters.length === 0 && /* @__PURE__ */ _jsxDEV("p", {
				className: "text-gray-500",
				children: "No active requesters found."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 9
			}, this),
			!loading && !error && requesters.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4",
				children: requesters.map((req) => /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => handleSelect(req),
					className: "bg-zenPrimary hover:bg-zenSecondary text-white font-semibold py-3 px-4 rounded-lg shadow-sm transition-colors text-center truncate",
					title: req.name,
					children: req.name
				}, req.id, false, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 45,
		columnNumber: 5
	}, this);
};
_s(DevRequesterSelector, "K1sSOvy1jQEjUDHas6nV7vP6byE=");
_c = DevRequesterSelector;
var _c;
$RefreshReg$(_c, "DevRequesterSelector");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/DevRequesterSelector.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/meebo/toktickit/client/src/components/DevRequesterSelector.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/meebo/toktickit/client/src/components/DevRequesterSelector.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/meebo/toktickit/client/src/components/DevRequesterSelector.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCOzs7O0FBVzNDLE9BQU8sTUFBTSx3QkFBeUMsRUFBRSxlQUFlOztDQUNyRSxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBc0IsQ0FBQyxDQUFDO0NBQzVELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBd0IsSUFBSTtDQUV0RCxnQkFBZ0I7RUFDZCxNQUFNLGtCQUFrQixZQUFZO0dBQ2xDLElBQUk7O0lBRUYsTUFBTSxXQUFXLE1BQU0sTUFBTSx3QkFBd0I7SUFDckQsSUFBSSxDQUFDLFNBQVMsSUFBSTtLQUNoQixNQUFNLElBQUksTUFBTSw0QkFBNEI7SUFDOUM7SUFDQSxNQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUs7SUFDakMsY0FBYyxJQUFJO0dBQ3BCLFNBQVMsS0FBVTtJQUNqQixRQUFRLE1BQU0sOEJBQThCLEdBQUc7SUFDL0MsU0FBUyxJQUFJLFdBQVcsbUJBQW1CO0dBQzdDLFVBQVU7SUFDUixXQUFXLEtBQUs7R0FDbEI7RUFDRjtFQUNBLGdCQUFnQjtDQUNsQixHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sZ0JBQWdCLGNBQXlCOztFQUU3QyxhQUFhLFFBQVEsdUJBQXVCLEtBQUssVUFBVSxTQUFTLENBQUM7O0VBRXJFLFNBQVMsU0FBUztDQUNwQjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLE1BQUQ7SUFBSSxXQUFVO2NBQXlDO0dBQStCOzs7OztHQUVyRixXQUFXLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWtCO0dBQXdCOzs7OztHQUNsRSxTQUFTLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWdCO0dBQVM7Ozs7O0dBRS9DLENBQUMsV0FBVyxDQUFDLFNBQVMsV0FBVyxXQUFXLEtBQzNDLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWdCO0dBQThCOzs7OztHQUc1RCxDQUFDLFdBQVcsQ0FBQyxTQUFTLFdBQVcsU0FBUyxLQUN6Qyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLFdBQVcsS0FBSyxRQUNmLHdCQUFDLFVBQUQ7S0FFRSxlQUFlLGFBQWEsR0FBRztLQUMvQixXQUFVO0tBQ1YsT0FBTyxJQUFJO2VBRVYsSUFBSTtJQUNDLEdBTkQsSUFBSTs7OztXQU1ILENBQ1Q7R0FDRTs7Ozs7RUFFSjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRGV2UmVxdWVzdGVyU2VsZWN0b3IudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuXG5pbnRlcmZhY2UgUmVxdWVzdGVyIHtcbiAgaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgUHJvcHMge1xuICBvblNlbGVjdDogKHJlcXVlc3RlcjogUmVxdWVzdGVyKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgRGV2UmVxdWVzdGVyU2VsZWN0b3I6IFJlYWN0LkZDPFByb3BzPiA9ICh7IG9uU2VsZWN0IH0pID0+IHtcbiAgY29uc3QgW3JlcXVlc3RlcnMsIHNldFJlcXVlc3RlcnNdID0gdXNlU3RhdGU8UmVxdWVzdGVyW10+KFtdKTtcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBmZXRjaFJlcXVlc3RlcnMgPSBhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICAvLyDguKLguLTguIcgQVBJIOC5hOC4m+C4l+C4teC5iCBHRVQgL2FwaS9yZXF1ZXN0ZXJzL2FjdGl2ZSDguJXguLLguKHguJfguLXguYjguKPguLDguJrguLhcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCgnL2FwaS9yZXF1ZXN0ZXJzL2FjdGl2ZScpO1xuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGYWlsZWQgdG8gZmV0Y2ggcmVxdWVzdGVycycpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICAgIHNldFJlcXVlc3RlcnMoZGF0YSk7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBmZXRjaGluZyByZXF1ZXN0ZXJzOicsIGVycik7XG4gICAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlIHx8ICdBbiBlcnJvciBvY2N1cnJlZCcpO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XG4gICAgICB9XG4gICAgfTtcbiAgICBmZXRjaFJlcXVlc3RlcnMoKTtcbiAgfSwgW10pO1xuXG4gIGNvbnN0IGhhbmRsZVNlbGVjdCA9IChyZXF1ZXN0ZXI6IFJlcXVlc3RlcikgPT4ge1xuICAgIC8vIDEpIOC4muC4seC4meC4l+C4tuC4geC4peC4hyBsb2NhbFN0b3JhZ2Ug4LiV4Liy4Lih4LmA4LiH4Li34LmI4Lit4LiZ4LmE4LiCXG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3Rva3RpY2tpdF9yZXF1ZXN0ZXInLCBKU09OLnN0cmluZ2lmeShyZXF1ZXN0ZXIpKTtcbiAgICAvLyAyKSDguYDguKPguLXguKLguIEgcHJvcHMgb25TZWxlY3RcbiAgICBvblNlbGVjdChyZXF1ZXN0ZXIpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWdyYXktMjAwIHAtNiBtdC02IG1heC13LTJ4bCBteC1hdXRvXCI+XG4gICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJvbGQgdGV4dC16ZW5QcmltYXJ5IG1iLTRcIj5TZWxlY3QgUmVxdWVzdGVyIChEZXYgTW9kZSk8L2gzPlxuICAgICAgXG4gICAgICB7bG9hZGluZyAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXplblByaW1hcnlcIj5Mb2FkaW5nIHJlcXVlc3RlcnMuLi48L3A+fVxuICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cInRleHQtcmVkLTYwMFwiPntlcnJvcn08L3A+fVxuICAgICAgXG4gICAgICB7IWxvYWRpbmcgJiYgIWVycm9yICYmIHJlcXVlc3RlcnMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTUwMFwiPk5vIGFjdGl2ZSByZXF1ZXN0ZXJzIGZvdW5kLjwvcD5cbiAgICAgICl9XG5cbiAgICAgIHshbG9hZGluZyAmJiAhZXJyb3IgJiYgcmVxdWVzdGVycy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIG1kOmdyaWQtY29scy0zIGdhcC00XCI+XG4gICAgICAgICAge3JlcXVlc3RlcnMubWFwKChyZXEpID0+IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAga2V5PXtyZXEuaWR9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbGVjdChyZXEpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy16ZW5QcmltYXJ5IGhvdmVyOmJnLXplblNlY29uZGFyeSB0ZXh0LXdoaXRlIGZvbnQtc2VtaWJvbGQgcHktMyBweC00IHJvdW5kZWQtbGcgc2hhZG93LXNtIHRyYW5zaXRpb24tY29sb3JzIHRleHQtY2VudGVyIHRydW5jYXRlXCJcbiAgICAgICAgICAgICAgdGl0bGU9e3JlcS5uYW1lfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7cmVxLm5hbWV9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==