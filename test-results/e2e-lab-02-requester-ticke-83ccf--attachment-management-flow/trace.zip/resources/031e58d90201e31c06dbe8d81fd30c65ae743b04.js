import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TicketDetail.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=15734ece";
import { getTicketById, deleteAttachment, uploadAttachmentToTicket, downloadAttachment } from "/src/api.ts";
var _jsxFileName = "C:/Users/meebo/toktickit/client/src/components/TicketDetail.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=15734ece";
var _s = $RefreshSig$();
export const TicketDetail = ({ ticketId, onBack }) => {
	_s();
	const [ticket, setTicket] = useState(null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const [deleteLoading, setDeleteLoading] = useState(null);
	const [uploadFile, setUploadFile] = useState(null);
	const [isUploading, setIsUploading] = useState(false);
	const [uploadError, setUploadError] = useState(null);
	const [downloadLoading, setDownloadLoading] = useState(null);
	const fetchTicket = async () => {
		try {
			const data = await getTicketById(ticketId);
			setTicket(data);
		} catch (err) {
			setError(err.message || "Failed to fetch ticket details");
		} finally {
			setLoading(false);
		}
	};
	useEffect(() => {
		fetchTicket();
	}, [ticketId]);
	const handleDeleteAttachment = async (attachmentId) => {
		if (!window.confirm("Are you sure you want to delete this attachment?")) return;
		setDeleteLoading(attachmentId);
		try {
			await deleteAttachment(ticketId, attachmentId);
			if (ticket) {
				setTicket({
					...ticket,
					attachments: ticket.attachments?.filter((a) => a.id !== attachmentId) || []
				});
			}
		} catch (err) {
			alert(err.message || "Failed to delete attachment");
		} finally {
			setDeleteLoading(null);
		}
	};
	const handleUpload = async () => {
		if (!uploadFile) return;
		setIsUploading(true);
		setUploadError(null);
		try {
			await uploadAttachmentToTicket(ticketId, uploadFile);
			// Refresh ticket details to show new attachment
			await fetchTicket();
			setUploadFile(null);
			// Reset input type="file" manually by finding it if needed, or rely on state.
			const fileInput = document.getElementById("attachment-upload-input");
			if (fileInput) fileInput.value = "";
		} catch (err) {
			setUploadError(err.message || "Failed to upload attachment");
		} finally {
			setIsUploading(false);
		}
	};
	const handleDownload = async (attachmentId, filename) => {
		setDownloadLoading(attachmentId);
		try {
			await downloadAttachment(ticketId, attachmentId, filename);
		} catch (err) {
			alert(err.message || "Failed to download attachment");
		} finally {
			setDownloadLoading(null);
		}
	};
	const formatSize = (bytes) => {
		if (bytes < 1024) return bytes + " B";
		else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB";
		else return (bytes / 1048576).toFixed(1) + " MB";
	};
	if (loading) return /* @__PURE__ */ _jsxDEV("div", {
		className: "p-6 text-zenPrimary font-medium",
		children: "Loading ticket details..."
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 111,
		columnNumber: 23
	}, this);
	if (error === "Forbidden") {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white rounded-lg shadow-sm border border-red-200 p-8 mt-6 max-w-2xl mx-auto text-center",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "text-red-500 mb-4 flex justify-center",
					children: /* @__PURE__ */ _jsxDEV("svg", {
						className: "w-16 h-16",
						fill: "none",
						stroke: "currentColor",
						viewBox: "0 0 24 24",
						xmlns: "http://www.w3.org/2000/svg",
						children: /* @__PURE__ */ _jsxDEV("path", {
							strokeLinecap: "round",
							strokeLinejoin: "round",
							strokeWidth: "2",
							d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 118,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 116,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-2xl font-bold text-gray-800 mb-2",
					children: "Access Denied"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-gray-600 mb-8 font-medium",
					children: "You do not have permission to view this ticket."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 122,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onBack,
					className: "bg-zenPrimary hover:bg-zenSecondary text-white px-6 py-2 rounded shadow-sm transition-colors font-semibold",
					children: "Back to My Tickets"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 123,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 115,
			columnNumber: 7
		}, this);
	}
	if (error || !ticket) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-6 max-w-2xl mx-auto text-center",
			children: [
				/* @__PURE__ */ _jsxDEV("h3", {
					className: "text-xl font-bold text-gray-800 mb-4",
					children: "Error"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-red-600 mb-6 font-medium",
					children: error || "Ticket not found"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 137,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onBack,
					className: "bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-6 py-2 rounded shadow-sm transition-colors",
					children: "Go Back"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 138,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 135,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-white rounded-lg shadow-sm border border-gray-200 p-6 mt-6 max-w-3xl mx-auto text-left relative",
		children: [
			/* @__PURE__ */ _jsxDEV("button", {
				onClick: onBack,
				className: "mb-6 flex items-center text-sm font-medium text-gray-500 hover:text-zenPrimary transition-colors",
				children: [/* @__PURE__ */ _jsxDEV("svg", {
					className: "w-4 h-4 mr-1",
					fill: "none",
					stroke: "currentColor",
					viewBox: "0 0 24 24",
					children: /* @__PURE__ */ _jsxDEV("path", {
						strokeLinecap: "round",
						strokeLinejoin: "round",
						strokeWidth: "2",
						d: "M10 19l-7-7m0 0l7-7m-7 7h18"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 154,
						columnNumber: 93
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 154,
					columnNumber: 9
				}, this), "Back to My Tickets"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 150,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex justify-between items-end mb-6 border-b pb-4 border-zenPrimary",
				children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-2xl font-bold text-gray-800",
					children: ticket.ticketNumber
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 160,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm text-gray-500 mt-1",
					children: ["Created on ", new Date(ticket.createdAt).toLocaleString()]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 161,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 159,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 158,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-6 mb-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm text-gray-500 font-semibold mb-1",
						children: "Status"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 167,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "inline-block px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium",
						children: ticket.status
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 168,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 166,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm text-gray-500 font-semibold mb-1",
						children: "Priority"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 173,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: `inline-block px-3 py-1 rounded-full text-sm font-medium ${ticket.requestedPriority === "High" || ticket.requestedPriority === "Critical" ? "bg-red-100 text-red-800" : ticket.requestedPriority === "Medium" ? "bg-yellow-100 text-yellow-800" : "bg-green-100 text-green-800"}`,
						children: ticket.requestedPriority
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 174,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm text-gray-500 font-semibold mb-1",
						children: "Category"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 183,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-gray-800",
						children: ticket.category?.name || "-"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 184,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 182,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm text-gray-500 font-semibold mb-1",
						children: "Related System"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 187,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-gray-800",
						children: ticket.relatedSystem?.name || "-"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 188,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 186,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 165,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-6",
				children: [/* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm text-gray-500 font-semibold mb-1",
					children: "Summary"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 193,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-gray-800 font-medium text-lg",
					children: ticket.summary
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 194,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 192,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mb-8",
				children: [/* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm text-gray-500 font-semibold mb-2",
					children: "Description"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 198,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-gray-50 p-4 rounded-lg border border-gray-100 text-gray-700 whitespace-pre-wrap",
					children: ticket.description
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 199,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 197,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "border-t border-gray-200 pt-6",
				children: [
					/* @__PURE__ */ _jsxDEV("h4", {
						className: "text-lg font-bold text-gray-800 mb-4",
						children: "Attachments"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 205,
						columnNumber: 9
					}, this),
					!ticket.attachments || ticket.attachments.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
						className: "text-gray-500 italic",
						children: "No attachments"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 208,
						columnNumber: 11
					}, this) : /* @__PURE__ */ _jsxDEV("ul", {
						className: "space-y-3",
						children: ticket.attachments.map((file) => /* @__PURE__ */ _jsxDEV("li", {
							className: "flex items-center justify-between p-3 bg-white border border-gray-200 rounded-lg shadow-sm",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center truncate mr-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-zenPale text-zenPrimary p-2 rounded mr-3",
									children: /* @__PURE__ */ _jsxDEV("svg", {
										className: "w-5 h-5",
										fill: "none",
										stroke: "currentColor",
										viewBox: "0 0 24 24",
										children: /* @__PURE__ */ _jsxDEV("path", {
											strokeLinecap: "round",
											strokeLinejoin: "round",
											strokeWidth: "2",
											d: "M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 215,
											columnNumber: 100
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 215,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 214,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "truncate",
									children: [/* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm font-medium text-gray-800 truncate",
										title: file.filename,
										children: file.filename
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 218,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-gray-500",
										children: formatSize(file.size)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 219,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 217,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 213,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex space-x-2 shrink-0",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleDownload(file.id, file.filename),
									disabled: downloadLoading === file.id,
									className: "px-3 py-1.5 text-xs font-semibold text-zenPrimary bg-zenPale hover:bg-zenPrimary hover:text-white rounded transition-colors disabled:opacity-50",
									children: downloadLoading === file.id ? "Downloading..." : "Download"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 223,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleDeleteAttachment(file.id),
									disabled: deleteLoading === file.id,
									className: "px-3 py-1.5 text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-600 hover:text-white rounded transition-colors disabled:opacity-50",
									children: deleteLoading === file.id ? "..." : "Delete"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 230,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 222,
								columnNumber: 17
							}, this)]
						}, file.id, true, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 210,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-6 pt-6 border-t border-gray-100",
						children: [
							/* @__PURE__ */ _jsxDEV("h5", {
								className: "text-sm font-bold text-gray-700 mb-3",
								children: "Add Attachment"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 245,
								columnNumber: 11
							}, this),
							uploadError && /* @__PURE__ */ _jsxDEV("div", {
								className: "mb-3 p-2 text-sm text-red-600 bg-red-50 border border-red-200 rounded",
								children: uploadError
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 248,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-3",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									id: "attachment-upload-input",
									type: "file",
									onChange: (e) => {
										setUploadFile(e.target.files?.[0] || null);
										setUploadError(null);
									},
									disabled: isUploading,
									className: "block w-full text-sm text-gray-500\n                file:mr-4 file:py-2 file:px-4\n                file:rounded file:border-0\n                file:text-sm file:font-semibold\n                file:bg-zenPale file:text-zenPrimary\n                hover:file:bg-zenPrimary hover:file:text-white\n                file:transition-colors file:cursor-pointer cursor-pointer border border-gray-200 rounded p-1"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 254,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleUpload,
									disabled: !uploadFile || isUploading,
									className: "px-4 py-2 bg-zenPrimary text-white text-sm font-semibold rounded shadow-sm hover:bg-zenSecondary disabled:opacity-50 disabled:cursor-not-allowed transition-colors shrink-0 flex items-center justify-center",
									children: isUploading ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("svg", {
										className: "animate-spin -ml-1 mr-2 h-4 w-4 text-white",
										xmlns: "http://www.w3.org/2000/svg",
										fill: "none",
										viewBox: "0 0 24 24",
										children: [/* @__PURE__ */ _jsxDEV("circle", {
											className: "opacity-25",
											cx: "12",
											cy: "12",
											r: "10",
											stroke: "currentColor",
											strokeWidth: "4"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 278,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("path", {
											className: "opacity-75",
											fill: "currentColor",
											d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 279,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 277,
										columnNumber: 19
									}, this), "Uploading..."] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 276,
										columnNumber: 17
									}, this) : "Upload"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 270,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 253,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 244,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 204,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 149,
		columnNumber: 5
	}, this);
};
_s(TicketDetail, "yKir7tXc45FYxGTDDY9FDhEHI+k=");
_c = TicketDetail;
var _c;
$RefreshReg$(_c, "TicketDetail");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/TicketDetail.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/meebo/toktickit/client/src/components/TicketDetail.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/meebo/toktickit/client/src/components/TicketDetail.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/meebo/toktickit/client/src/components/TicketDetail.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsZUFBZSxrQkFBa0IsMEJBQTBCLDBCQUEwQjs7OztBQTJCOUYsT0FBTyxNQUFNLGdCQUFpQyxFQUFFLFVBQVUsYUFBYTs7Q0FDckUsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUF3QixJQUFJO0NBQ3hELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBd0IsSUFBSTtDQUV0RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBd0IsSUFBSTtDQUN0RSxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBc0IsSUFBSTtDQUM5RCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBQ3BELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUF3QixJQUFJO0NBQ2xFLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQXdCLElBQUk7Q0FFMUUsTUFBTSxjQUFjLFlBQVk7RUFDOUIsSUFBSTtHQUNGLE1BQU0sT0FBTyxNQUFNLGNBQWMsUUFBUTtHQUN6QyxVQUFVLElBQUk7RUFDaEIsU0FBUyxLQUFVO0dBQ2pCLFNBQVMsSUFBSSxXQUFXLGdDQUFnQztFQUMxRCxVQUFVO0dBQ1IsV0FBVyxLQUFLO0VBQ2xCO0NBQ0Y7Q0FFQSxnQkFBZ0I7RUFDZCxZQUFZO0NBQ2QsR0FBRyxDQUFDLFFBQVEsQ0FBQztDQUViLE1BQU0seUJBQXlCLE9BQU8saUJBQXlCO0VBQzdELElBQUksQ0FBQyxPQUFPLFFBQVEsa0RBQWtELEdBQUc7RUFFekUsaUJBQWlCLFlBQVk7RUFDN0IsSUFBSTtHQUNGLE1BQU0saUJBQWlCLFVBQVUsWUFBWTtHQUM3QyxJQUFJLFFBQVE7SUFDVixVQUFVO0tBQ1IsR0FBRztLQUNILGFBQWEsT0FBTyxhQUFhLFFBQU8sTUFBSyxFQUFFLE9BQU8sWUFBWSxLQUFLLENBQUM7SUFDMUUsQ0FBQztHQUNIO0VBQ0YsU0FBUyxLQUFVO0dBQ2pCLE1BQU0sSUFBSSxXQUFXLDZCQUE2QjtFQUNwRCxVQUFVO0dBQ1IsaUJBQWlCLElBQUk7RUFDdkI7Q0FDRjtDQUVBLE1BQU0sZUFBZSxZQUFZO0VBQy9CLElBQUksQ0FBQyxZQUFZO0VBRWpCLGVBQWUsSUFBSTtFQUNuQixlQUFlLElBQUk7RUFDbkIsSUFBSTtHQUNGLE1BQU0seUJBQXlCLFVBQVUsVUFBVTs7R0FFbkQsTUFBTSxZQUFZO0dBQ2xCLGNBQWMsSUFBSTs7R0FFbEIsTUFBTSxZQUFZLFNBQVMsZUFBZSx5QkFBeUI7R0FDbkUsSUFBSSxXQUFXLFVBQVUsUUFBUTtFQUNuQyxTQUFTLEtBQVU7R0FDakIsZUFBZSxJQUFJLFdBQVcsNkJBQTZCO0VBQzdELFVBQVU7R0FDUixlQUFlLEtBQUs7RUFDdEI7Q0FDRjtDQUVBLE1BQU0saUJBQWlCLE9BQU8sY0FBc0IsYUFBcUI7RUFDdkUsbUJBQW1CLFlBQVk7RUFDL0IsSUFBSTtHQUNGLE1BQU0sbUJBQW1CLFVBQVUsY0FBYyxRQUFRO0VBQzNELFNBQVMsS0FBVTtHQUNqQixNQUFNLElBQUksV0FBVywrQkFBK0I7RUFDdEQsVUFBVTtHQUNSLG1CQUFtQixJQUFJO0VBQ3pCO0NBQ0Y7Q0FFQSxNQUFNLGNBQWMsVUFBa0I7RUFDcEMsSUFBSSxRQUFRLE1BQU0sT0FBTyxRQUFRO09BQzVCLElBQUksUUFBUSxTQUFTLFFBQVEsUUFBUSxLQUFJLENBQUUsUUFBUSxDQUFDLElBQUk7T0FDeEQsUUFBUSxRQUFRLFFBQU8sQ0FBRSxRQUFRLENBQUMsSUFBSTtDQUM3QztDQUVBLElBQUksU0FBUyxPQUFPLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWtDO0NBQThCOzs7OztDQUVuRyxJQUFJLFVBQVUsYUFBYTtFQUN6QixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO01BQVksTUFBSztNQUFPLFFBQU87TUFBZSxTQUFRO01BQVksT0FBTTtnQkFDckYsd0JBQUMsUUFBRDtPQUFNLGVBQWM7T0FBUSxnQkFBZTtPQUFRLGFBQVk7T0FBSSxHQUFFO01BQTZJOzs7OztLQUMvTTs7Ozs7SUFDRjs7Ozs7SUFDTCx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUF3QztJQUFpQjs7Ozs7SUFDdkUsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBaUM7SUFBa0Q7Ozs7O0lBQ2hHLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtlQUNYO0lBRU87Ozs7O0dBQ0w7Ozs7OztDQUVUO0NBRUEsSUFBSSxTQUFTLENBQUMsUUFBUTtFQUNwQixPQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUF1QztJQUFTOzs7OztJQUM5RCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFpQyxTQUFTO0lBQXNCOzs7OztJQUM3RSx3QkFBQyxVQUFEO0tBQ0UsU0FBUztLQUNULFdBQVU7ZUFDWDtJQUVPOzs7OztHQUNMOzs7Ozs7Q0FFVDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLFVBQUQ7SUFDRSxTQUFTO0lBQ1QsV0FBVTtjQUZaLENBSUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBZSxNQUFLO0tBQU8sUUFBTztLQUFlLFNBQVE7ZUFBWSx3QkFBQyxRQUFEO01BQU0sZUFBYztNQUFRLGdCQUFlO01BQVEsYUFBWTtNQUFJLEdBQUU7S0FBb0M7Ozs7O0lBQU07Ozs7Y0FBQyxvQkFFOUw7Ozs7OztHQUVSLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFVO2VBQW9DLE9BQU87SUFBaUI7Ozs7Y0FDMUUsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBYixDQUEwQyxlQUFZLElBQUksS0FBSyxPQUFPLFNBQVMsQ0FBQyxDQUFDLGVBQWUsQ0FBSzs7Ozs7WUFDbEc7Ozs7O0dBQ0Y7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBMkM7S0FBUzs7OztlQUNqRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFDYixPQUFPO0tBQ0o7Ozs7YUFDSDs7Ozs7S0FDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQTJDO0tBQVc7Ozs7ZUFDbkUsd0JBQUMsUUFBRDtNQUFNLFdBQVcsMkRBQ2YsT0FBTyxzQkFBc0IsVUFBVSxPQUFPLHNCQUFzQixhQUFhLDRCQUNqRixPQUFPLHNCQUFzQixXQUFXLGtDQUN4QztnQkFFQyxPQUFPO0tBQ0o7Ozs7YUFDSDs7Ozs7S0FDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQTJDO0tBQVc7Ozs7ZUFDbkUsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWlCLE9BQU8sVUFBVSxRQUFRO0tBQU87Ozs7YUFDM0Q7Ozs7O0tBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUEyQztLQUFpQjs7OztlQUN6RSx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBaUIsT0FBTyxlQUFlLFFBQVE7S0FBTzs7OzthQUNoRTs7Ozs7SUFDRjs7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQTJDO0lBQVU7Ozs7Y0FDbEUsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBcUMsT0FBTztJQUFXOzs7O1lBQ2pFOzs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBMkM7SUFBYzs7OztjQUN0RSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLE9BQU87SUFDTDs7OztZQUNGOzs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXVDO0tBQWU7Ozs7O0tBRWxFLENBQUMsT0FBTyxlQUFlLE9BQU8sWUFBWSxXQUFXLElBQ3JELHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUF1QjtLQUFpQjs7OztnQkFFckQsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQ1gsT0FBTyxZQUFZLEtBQUssU0FDdkIsd0JBQUMsTUFBRDtPQUFrQixXQUFVO2lCQUE1QixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ2Isd0JBQUMsT0FBRDtVQUFLLFdBQVU7VUFBVSxNQUFLO1VBQU8sUUFBTztVQUFlLFNBQVE7b0JBQVksd0JBQUMsUUFBRDtXQUFNLGVBQWM7V0FBUSxnQkFBZTtXQUFRLGFBQVk7V0FBSSxHQUFFO1VBQTZIOzs7OztTQUFNOzs7OztRQUNwUjs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO1VBQTZDLE9BQU8sS0FBSztvQkFBVyxLQUFLO1NBQVk7Ozs7bUJBQ2xHLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUF5QixXQUFXLEtBQUssSUFBSTtTQUFLOzs7O2lCQUM1RDs7Ozs7Z0JBQ0Y7Ozs7O2lCQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsVUFBRDtTQUNFLGVBQWUsZUFBZSxLQUFLLElBQUksS0FBSyxRQUFRO1NBQ3BELFVBQVUsb0JBQW9CLEtBQUs7U0FDbkMsV0FBVTttQkFFVCxvQkFBb0IsS0FBSyxLQUFLLG1CQUFtQjtRQUM1Qzs7OztrQkFDUix3QkFBQyxVQUFEO1NBQ0UsZUFBZSx1QkFBdUIsS0FBSyxFQUFFO1NBQzdDLFVBQVUsa0JBQWtCLEtBQUs7U0FDakMsV0FBVTttQkFFVCxrQkFBa0IsS0FBSyxLQUFLLFFBQVE7UUFDL0I7Ozs7Z0JBQ0w7Ozs7O2VBQ0g7U0ExQkssS0FBSzs7OzthQTBCVixDQUNMO0tBQ0M7Ozs7O0tBSU4sd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBdUM7T0FBa0I7Ozs7O09BRXRFLGVBQ0Msd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1o7T0FDRTs7Ozs7T0FHUCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFNBQUQ7U0FDRSxJQUFHO1NBQ0gsTUFBSztTQUNMLFdBQVcsTUFBTTtVQUNmLGNBQWMsRUFBRSxPQUFPLFFBQVEsTUFBTSxJQUFJO1VBQ3pDLGVBQWUsSUFBSTtTQUNyQjtTQUNBLFVBQVU7U0FDVixXQUFVO1FBT1g7Ozs7a0JBQ0Qsd0JBQUMsVUFBRDtTQUNFLFNBQVM7U0FDVCxVQUFVLENBQUMsY0FBYztTQUN6QixXQUFVO21CQUVULGNBQ0MsZ0RBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7VUFBNkMsT0FBTTtVQUE2QixNQUFLO1VBQU8sU0FBUTtvQkFBbkgsQ0FDRSx3QkFBQyxVQUFEO1dBQVEsV0FBVTtXQUFhLElBQUc7V0FBSyxJQUFHO1dBQUssR0FBRTtXQUFLLFFBQU87V0FBZSxhQUFZO1VBQVk7Ozs7b0JBQ3BHLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO1dBQWEsTUFBSztXQUFlLEdBQUU7VUFBd0g7Ozs7a0JBQ3hLOzs7OzttQkFBQyxjQUVOOzs7O29CQUVGO1FBRUk7Ozs7Z0JBQ0w7Ozs7OztNQUNGOzs7Ozs7SUFFRjs7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRpY2tldERldGFpbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBnZXRUaWNrZXRCeUlkLCBkZWxldGVBdHRhY2htZW50LCB1cGxvYWRBdHRhY2htZW50VG9UaWNrZXQsIGRvd25sb2FkQXR0YWNobWVudCB9IGZyb20gJy4uL2FwaSc7XG5cbmludGVyZmFjZSBBdHRhY2htZW50IHtcbiAgaWQ6IHN0cmluZztcbiAgZmlsZW5hbWU6IHN0cmluZztcbiAgbWltZXR5cGU6IHN0cmluZztcbiAgc2l6ZTogbnVtYmVyO1xufVxuXG5pbnRlcmZhY2UgVGlja2V0IHtcbiAgaWQ6IHN0cmluZztcbiAgdGlja2V0TnVtYmVyOiBzdHJpbmc7XG4gIHJlcXVlc3RlZFByaW9yaXR5OiBzdHJpbmc7XG4gIHN0YXR1czogc3RyaW5nO1xuICBzdW1tYXJ5OiBzdHJpbmc7XG4gIGRlc2NyaXB0aW9uOiBzdHJpbmc7XG4gIGNyZWF0ZWRBdDogc3RyaW5nO1xuICBjYXRlZ29yeT86IHsgbmFtZTogc3RyaW5nIH07XG4gIHJlbGF0ZWRTeXN0ZW0/OiB7IG5hbWU6IHN0cmluZyB9O1xuICBhdHRhY2htZW50cz86IEF0dGFjaG1lbnRbXTtcbn1cblxuaW50ZXJmYWNlIFByb3BzIHtcbiAgdGlja2V0SWQ6IHN0cmluZztcbiAgb25CYWNrOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgVGlja2V0RGV0YWlsOiBSZWFjdC5GQzxQcm9wcz4gPSAoeyB0aWNrZXRJZCwgb25CYWNrIH0pID0+IHtcbiAgY29uc3QgW3RpY2tldCwgc2V0VGlja2V0XSA9IHVzZVN0YXRlPFRpY2tldCB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgXG4gIGNvbnN0IFtkZWxldGVMb2FkaW5nLCBzZXREZWxldGVMb2FkaW5nXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbdXBsb2FkRmlsZSwgc2V0VXBsb2FkRmlsZV0gPSB1c2VTdGF0ZTxGaWxlIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtpc1VwbG9hZGluZywgc2V0SXNVcGxvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbdXBsb2FkRXJyb3IsIHNldFVwbG9hZEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbZG93bmxvYWRMb2FkaW5nLCBzZXREb3dubG9hZExvYWRpbmddID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgZmV0Y2hUaWNrZXQgPSBhc3luYyAoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZXRUaWNrZXRCeUlkKHRpY2tldElkKTtcbiAgICAgIHNldFRpY2tldChkYXRhKTtcbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UgfHwgJ0ZhaWxlZCB0byBmZXRjaCB0aWNrZXQgZGV0YWlscycpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBmZXRjaFRpY2tldCgpO1xuICB9LCBbdGlja2V0SWRdKTtcblxuICBjb25zdCBoYW5kbGVEZWxldGVBdHRhY2htZW50ID0gYXN5bmMgKGF0dGFjaG1lbnRJZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKCF3aW5kb3cuY29uZmlybSgnQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSB0aGlzIGF0dGFjaG1lbnQ/JykpIHJldHVybjtcbiAgICBcbiAgICBzZXREZWxldGVMb2FkaW5nKGF0dGFjaG1lbnRJZCk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGRlbGV0ZUF0dGFjaG1lbnQodGlja2V0SWQsIGF0dGFjaG1lbnRJZCk7XG4gICAgICBpZiAodGlja2V0KSB7XG4gICAgICAgIHNldFRpY2tldCh7XG4gICAgICAgICAgLi4udGlja2V0LFxuICAgICAgICAgIGF0dGFjaG1lbnRzOiB0aWNrZXQuYXR0YWNobWVudHM/LmZpbHRlcihhID0+IGEuaWQgIT09IGF0dGFjaG1lbnRJZCkgfHwgW11cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIGFsZXJ0KGVyci5tZXNzYWdlIHx8ICdGYWlsZWQgdG8gZGVsZXRlIGF0dGFjaG1lbnQnKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0RGVsZXRlTG9hZGluZyhudWxsKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlVXBsb2FkID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghdXBsb2FkRmlsZSkgcmV0dXJuO1xuICAgIFxuICAgIHNldElzVXBsb2FkaW5nKHRydWUpO1xuICAgIHNldFVwbG9hZEVycm9yKG51bGwpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCB1cGxvYWRBdHRhY2htZW50VG9UaWNrZXQodGlja2V0SWQsIHVwbG9hZEZpbGUpO1xuICAgICAgLy8gUmVmcmVzaCB0aWNrZXQgZGV0YWlscyB0byBzaG93IG5ldyBhdHRhY2htZW50XG4gICAgICBhd2FpdCBmZXRjaFRpY2tldCgpO1xuICAgICAgc2V0VXBsb2FkRmlsZShudWxsKTtcbiAgICAgIC8vIFJlc2V0IGlucHV0IHR5cGU9XCJmaWxlXCIgbWFudWFsbHkgYnkgZmluZGluZyBpdCBpZiBuZWVkZWQsIG9yIHJlbHkgb24gc3RhdGUuXG4gICAgICBjb25zdCBmaWxlSW5wdXQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYXR0YWNobWVudC11cGxvYWQtaW5wdXQnKSBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICAgICAgaWYgKGZpbGVJbnB1dCkgZmlsZUlucHV0LnZhbHVlID0gJyc7XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIHNldFVwbG9hZEVycm9yKGVyci5tZXNzYWdlIHx8ICdGYWlsZWQgdG8gdXBsb2FkIGF0dGFjaG1lbnQnKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNVcGxvYWRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVEb3dubG9hZCA9IGFzeW5jIChhdHRhY2htZW50SWQ6IHN0cmluZywgZmlsZW5hbWU6IHN0cmluZykgPT4ge1xuICAgIHNldERvd25sb2FkTG9hZGluZyhhdHRhY2htZW50SWQpO1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBkb3dubG9hZEF0dGFjaG1lbnQodGlja2V0SWQsIGF0dGFjaG1lbnRJZCwgZmlsZW5hbWUpO1xuICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICBhbGVydChlcnIubWVzc2FnZSB8fCAnRmFpbGVkIHRvIGRvd25sb2FkIGF0dGFjaG1lbnQnKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0RG93bmxvYWRMb2FkaW5nKG51bGwpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBmb3JtYXRTaXplID0gKGJ5dGVzOiBudW1iZXIpID0+IHtcbiAgICBpZiAoYnl0ZXMgPCAxMDI0KSByZXR1cm4gYnl0ZXMgKyAnIEInO1xuICAgIGVsc2UgaWYgKGJ5dGVzIDwgMTA0ODU3NikgcmV0dXJuIChieXRlcyAvIDEwMjQpLnRvRml4ZWQoMSkgKyAnIEtCJztcbiAgICBlbHNlIHJldHVybiAoYnl0ZXMgLyAxMDQ4NTc2KS50b0ZpeGVkKDEpICsgJyBNQic7XG4gIH07XG5cbiAgaWYgKGxvYWRpbmcpIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cInAtNiB0ZXh0LXplblByaW1hcnkgZm9udC1tZWRpdW1cIj5Mb2FkaW5nIHRpY2tldCBkZXRhaWxzLi4uPC9kaXY+O1xuXG4gIGlmIChlcnJvciA9PT0gJ0ZvcmJpZGRlbicpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLXJlZC0yMDAgcC04IG10LTYgbWF4LXctMnhsIG14LWF1dG8gdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJlZC01MDAgbWItNCBmbGV4IGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTE2IGgtMTZcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI+XG4gICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xMiA5djJtMCA0aC4wMW0tNi45MzggNGgxMy44NTZjMS41NCAwIDIuNTAyLTEuNjY3IDEuNzMyLTNMMTMuNzMyIDRjLS43Ny0xLjMzMy0yLjY5NC0xLjMzMy0zLjQ2NCAwTDMuMzQgMTZjLS43NyAxLjMzMy4xOTIgMyAxLjczMiAzelwiPjwvcGF0aD5cbiAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMCBtYi0yXCI+QWNjZXNzIERlbmllZDwvaDM+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS02MDAgbWItOCBmb250LW1lZGl1bVwiPllvdSBkbyBub3QgaGF2ZSBwZXJtaXNzaW9uIHRvIHZpZXcgdGhpcyB0aWNrZXQuPC9wPlxuICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgIG9uQ2xpY2s9e29uQmFja31cbiAgICAgICAgICBjbGFzc05hbWU9XCJiZy16ZW5QcmltYXJ5IGhvdmVyOmJnLXplblNlY29uZGFyeSB0ZXh0LXdoaXRlIHB4LTYgcHktMiByb3VuZGVkIHNoYWRvdy1zbSB0cmFuc2l0aW9uLWNvbG9ycyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgPlxuICAgICAgICAgIEJhY2sgdG8gTXkgVGlja2V0c1xuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgICk7XG4gIH1cblxuICBpZiAoZXJyb3IgfHwgIXRpY2tldCkge1xuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC02IG10LTYgbWF4LXctMnhsIG14LWF1dG8gdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgbWItNFwiPkVycm9yPC9oMz5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1yZWQtNjAwIG1iLTYgZm9udC1tZWRpdW1cIj57ZXJyb3IgfHwgJ1RpY2tldCBub3QgZm91bmQnfTwvcD5cbiAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICBvbkNsaWNrPXtvbkJhY2t9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBob3ZlcjpiZy1ncmF5LTUwIHRleHQtZ3JheS03MDAgcHgtNiBweS0yIHJvdW5kZWQgc2hhZG93LXNtIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgPlxuICAgICAgICAgIEdvIEJhY2tcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcC02IG10LTYgbWF4LXctM3hsIG14LWF1dG8gdGV4dC1sZWZ0IHJlbGF0aXZlXCI+XG4gICAgICA8YnV0dG9uIFxuICAgICAgICBvbkNsaWNrPXtvbkJhY2t9XG4gICAgICAgIGNsYXNzTmFtZT1cIm1iLTYgZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIGhvdmVyOnRleHQtemVuUHJpbWFyeSB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICA+XG4gICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy00IGgtNCBtci0xXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+PHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTAgMTlsLTctN20wIDBsNy03bS03IDdoMThcIj48L3BhdGg+PC9zdmc+XG4gICAgICAgIEJhY2sgdG8gTXkgVGlja2V0c1xuICAgICAgPC9idXR0b24+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtZW5kIG1iLTYgYm9yZGVyLWIgcGItNCBib3JkZXItemVuUHJpbWFyeVwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdGV4dC1ncmF5LTgwMFwiPnt0aWNrZXQudGlja2V0TnVtYmVyfTwvaDI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIG10LTFcIj5DcmVhdGVkIG9uIHtuZXcgRGF0ZSh0aWNrZXQuY3JlYXRlZEF0KS50b0xvY2FsZVN0cmluZygpfTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02IG1iLTZcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgZm9udC1zZW1pYm9sZCBtYi0xXCI+U3RhdHVzPC9wPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImlubGluZS1ibG9jayBweC0zIHB5LTEgYmctYmx1ZS0xMDAgdGV4dC1ibHVlLTgwMCByb3VuZGVkLWZ1bGwgdGV4dC1zbSBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAge3RpY2tldC5zdGF0dXN9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgZm9udC1zZW1pYm9sZCBtYi0xXCI+UHJpb3JpdHk8L3A+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgaW5saW5lLWJsb2NrIHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgdGV4dC1zbSBmb250LW1lZGl1bSAke1xuICAgICAgICAgICAgdGlja2V0LnJlcXVlc3RlZFByaW9yaXR5ID09PSAnSGlnaCcgfHwgdGlja2V0LnJlcXVlc3RlZFByaW9yaXR5ID09PSAnQ3JpdGljYWwnID8gJ2JnLXJlZC0xMDAgdGV4dC1yZWQtODAwJyA6XG4gICAgICAgICAgICB0aWNrZXQucmVxdWVzdGVkUHJpb3JpdHkgPT09ICdNZWRpdW0nID8gJ2JnLXllbGxvdy0xMDAgdGV4dC15ZWxsb3ctODAwJyA6XG4gICAgICAgICAgICAnYmctZ3JlZW4tMTAwIHRleHQtZ3JlZW4tODAwJ1xuICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgIHt0aWNrZXQucmVxdWVzdGVkUHJpb3JpdHl9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgZm9udC1zZW1pYm9sZCBtYi0xXCI+Q2F0ZWdvcnk8L3A+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1ncmF5LTgwMFwiPnt0aWNrZXQuY2F0ZWdvcnk/Lm5hbWUgfHwgJy0nfTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LWdyYXktNTAwIGZvbnQtc2VtaWJvbGQgbWItMVwiPlJlbGF0ZWQgU3lzdGVtPC9wPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtZ3JheS04MDBcIj57dGlja2V0LnJlbGF0ZWRTeXN0ZW0/Lm5hbWUgfHwgJy0nfTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1ncmF5LTUwMCBmb250LXNlbWlib2xkIG1iLTFcIj5TdW1tYXJ5PC9wPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktODAwIGZvbnQtbWVkaXVtIHRleHQtbGdcIj57dGlja2V0LnN1bW1hcnl9PC9wPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItOFwiPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtZ3JheS01MDAgZm9udC1zZW1pYm9sZCBtYi0yXCI+RGVzY3JpcHRpb248L3A+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JheS01MCBwLTQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWdyYXktMTAwIHRleHQtZ3JheS03MDAgd2hpdGVzcGFjZS1wcmUtd3JhcFwiPlxuICAgICAgICAgIHt0aWNrZXQuZGVzY3JpcHRpb259XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLWdyYXktMjAwIHB0LTZcIj5cbiAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtZ3JheS04MDAgbWItNFwiPkF0dGFjaG1lbnRzPC9oND5cbiAgICAgICAgXG4gICAgICAgIHsoIXRpY2tldC5hdHRhY2htZW50cyB8fCB0aWNrZXQuYXR0YWNobWVudHMubGVuZ3RoID09PSAwKSA/IChcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWdyYXktNTAwIGl0YWxpY1wiPk5vIGF0dGFjaG1lbnRzPC9wPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIHt0aWNrZXQuYXR0YWNobWVudHMubWFwKChmaWxlKSA9PiAoXG4gICAgICAgICAgICAgIDxsaSBrZXk9e2ZpbGUuaWR9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwLTMgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCByb3VuZGVkLWxnIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgdHJ1bmNhdGUgbXItNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy16ZW5QYWxlIHRleHQtemVuUHJpbWFyeSBwLTIgcm91bmRlZCBtci0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy01IGgtNVwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPjxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTE1LjE3MiA3bC02LjU4NiA2LjU4NmEyIDIgMCAxMDIuODI4IDIuODI4bDYuNDE0LTYuNTg2YTQgNCAwIDAwLTUuNjU2LTUuNjU2bC02LjQxNSA2LjU4NWE2IDYgMCAxMDguNDg2IDguNDg2TDIwLjUgMTNcIj48L3BhdGg+PC9zdmc+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LWdyYXktODAwIHRydW5jYXRlXCIgdGl0bGU9e2ZpbGUuZmlsZW5hbWV9PntmaWxlLmZpbGVuYW1lfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwXCI+e2Zvcm1hdFNpemUoZmlsZS5zaXplKX08L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc3BhY2UteC0yIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEb3dubG9hZChmaWxlLmlkLCBmaWxlLmZpbGVuYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rvd25sb2FkTG9hZGluZyA9PT0gZmlsZS5pZH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtemVuUHJpbWFyeSBiZy16ZW5QYWxlIGhvdmVyOmJnLXplblByaW1hcnkgaG92ZXI6dGV4dC13aGl0ZSByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7ZG93bmxvYWRMb2FkaW5nID09PSBmaWxlLmlkID8gJ0Rvd25sb2FkaW5nLi4uJyA6ICdEb3dubG9hZCd9XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b24gXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZURlbGV0ZUF0dGFjaG1lbnQoZmlsZS5pZCl9XG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtkZWxldGVMb2FkaW5nID09PSBmaWxlLmlkfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1yZWQtNjAwIGJnLXJlZC01MCBob3ZlcjpiZy1yZWQtNjAwIGhvdmVyOnRleHQtd2hpdGUgcm91bmRlZCB0cmFuc2l0aW9uLWNvbG9ycyBkaXNhYmxlZDpvcGFjaXR5LTUwXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2RlbGV0ZUxvYWRpbmcgPT09IGZpbGUuaWQgPyAnLi4uJyA6ICdEZWxldGUnfVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L3VsPlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBVcGxvYWQgTmV3IEF0dGFjaG1lbnQgU2VjdGlvbiAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC02IHB0LTYgYm9yZGVyLXQgYm9yZGVyLWdyYXktMTAwXCI+XG4gICAgICAgICAgPGg1IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtZ3JheS03MDAgbWItM1wiPkFkZCBBdHRhY2htZW50PC9oNT5cbiAgICAgICAgICBcbiAgICAgICAgICB7dXBsb2FkRXJyb3IgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0zIHAtMiB0ZXh0LXNtIHRleHQtcmVkLTYwMCBiZy1yZWQtNTAgYm9yZGVyIGJvcmRlci1yZWQtMjAwIHJvdW5kZWRcIj5cbiAgICAgICAgICAgICAge3VwbG9hZEVycm9yfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIgc3BhY2UteS0zIHNtOnNwYWNlLXktMCBzbTpzcGFjZS14LTNcIj5cbiAgICAgICAgICAgIDxpbnB1dCBcbiAgICAgICAgICAgICAgaWQ9XCJhdHRhY2htZW50LXVwbG9hZC1pbnB1dFwiXG4gICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCIgXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgIHNldFVwbG9hZEZpbGUoZS50YXJnZXQuZmlsZXM/LlswXSB8fCBudWxsKTtcbiAgICAgICAgICAgICAgICBzZXRVcGxvYWRFcnJvcihudWxsKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzVXBsb2FkaW5nfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJibG9jayB3LWZ1bGwgdGV4dC1zbSB0ZXh0LWdyYXktNTAwXG4gICAgICAgICAgICAgICAgZmlsZTptci00IGZpbGU6cHktMiBmaWxlOnB4LTRcbiAgICAgICAgICAgICAgICBmaWxlOnJvdW5kZWQgZmlsZTpib3JkZXItMFxuICAgICAgICAgICAgICAgIGZpbGU6dGV4dC1zbSBmaWxlOmZvbnQtc2VtaWJvbGRcbiAgICAgICAgICAgICAgICBmaWxlOmJnLXplblBhbGUgZmlsZTp0ZXh0LXplblByaW1hcnlcbiAgICAgICAgICAgICAgICBob3ZlcjpmaWxlOmJnLXplblByaW1hcnkgaG92ZXI6ZmlsZTp0ZXh0LXdoaXRlXG4gICAgICAgICAgICAgICAgZmlsZTp0cmFuc2l0aW9uLWNvbG9ycyBmaWxlOmN1cnNvci1wb2ludGVyIGN1cnNvci1wb2ludGVyIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZCBwLTFcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlVXBsb2FkfVxuICAgICAgICAgICAgICBkaXNhYmxlZD17IXVwbG9hZEZpbGUgfHwgaXNVcGxvYWRpbmd9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy16ZW5QcmltYXJ5IHRleHQtd2hpdGUgdGV4dC1zbSBmb250LXNlbWlib2xkIHJvdW5kZWQgc2hhZG93LXNtIGhvdmVyOmJnLXplblNlY29uZGFyeSBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCB0cmFuc2l0aW9uLWNvbG9ycyBzaHJpbmstMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtpc1VwbG9hZGluZyA/IChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gLW1sLTEgbXItMiBoLTQgdy00IHRleHQtd2hpdGVcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgZmlsbD1cIm5vbmVcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+XG4gICAgICAgICAgICAgICAgICAgIDxjaXJjbGUgY2xhc3NOYW1lPVwib3BhY2l0eS0yNVwiIGN4PVwiMTJcIiBjeT1cIjEyXCIgcj1cIjEwXCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCIgc3Ryb2tlV2lkdGg9XCI0XCI+PC9jaXJjbGU+XG4gICAgICAgICAgICAgICAgICAgIDxwYXRoIGNsYXNzTmFtZT1cIm9wYWNpdHktNzVcIiBmaWxsPVwiY3VycmVudENvbG9yXCIgZD1cIk00IDEyYTggOCAwIDAxOC04VjBDNS4zNzMgMCAwIDUuMzczIDAgMTJoNHptMiA1LjI5MUE3Ljk2MiA3Ljk2MiAwIDAxNCAxMkgwYzAgMy4wNDIgMS4xMzUgNS44MjQgMyA3LjkzOGwzLTIuNjQ3elwiPjwvcGF0aD5cbiAgICAgICAgICAgICAgICAgIDwvc3ZnPlxuICAgICAgICAgICAgICAgICAgVXBsb2FkaW5nLi4uXG4gICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgJ1VwbG9hZCdcbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19